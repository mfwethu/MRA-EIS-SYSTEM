-- Create a function to calculate VAT amount from total
CREATE FUNCTION dbo.CalculateVATFromTotal(@Total DECIMAL(18,2))
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @VAT_RATE DECIMAL(5,3) = 0.175
    DECLARE @BaseAmount DECIMAL(18,2)
    DECLARE @VAT DECIMAL(18,2)
    
    SET @BaseAmount = @Total / (1 + @VAT_RATE)
    SET @VAT = @Total - @BaseAmount
    
    RETURN ROUND(@VAT, 2)
END

-- Create a function to calculate base amount from total
CREATE FUNCTION dbo.CalculateBaseAmountFromTotal(@Total DECIMAL(18,2))
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @VAT_RATE DECIMAL(5,3) = 0.175
    DECLARE @BaseAmount DECIMAL(18,2)
    
    SET @BaseAmount = @Total / (1 + @VAT_RATE)
    
    RETURN ROUND(@BaseAmount, 2)
END

-- Create a function to calculate total from base amount
CREATE FUNCTION dbo.CalculateTotalFromBaseAmount(@BaseAmount DECIMAL(18,2))
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @VAT_RATE DECIMAL(5,3) = 0.175
    DECLARE @Total DECIMAL(18,2)
    
    SET @Total = @BaseAmount * (1 + @VAT_RATE)
    
    RETURN ROUND(@Total, 2)
END