-- Add table to track inventory uploads
CREATE TABLE InventoryUploadHistory (
    UploadHistoryId INT IDENTITY(1,1) PRIMARY KEY,
    InventoryId INT NOT NULL,
    UploadedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    Status NVARCHAR(50) NOT NULL, -- 'SUCCESS', 'FAILED', 'PENDING'
    MRAResponse NVARCHAR(MAX),
    ErrorMessage NVARCHAR(MAX),
    IsLastBatch BIT NOT NULL DEFAULT 0,
    
    CONSTRAINT FK_UploadHistory_Inventory FOREIGN KEY (InventoryId) REFERENCES InventoryUpload(InventoryId),
    CONSTRAINT CK_UploadStatus CHECK (Status IN ('SUCCESS', 'FAILED', 'PENDING'))
);

CREATE INDEX idx_UploadHistory_InventoryId ON InventoryUploadHistory(InventoryId);
CREATE INDEX idx_UploadHistory_UploadedAt ON InventoryUploadHistory(UploadedAt);
CREATE INDEX idx_UploadHistory_Status ON InventoryUploadHistory(Status);

-- Add table for failed inventory submissions
CREATE TABLE FailedInventorySubmissions (
    FailureId INT IDENTITY(1,1) PRIMARY KEY,
    InventoryId INT NOT NULL,
    ErrorMessage NVARCHAR(MAX) NOT NULL,
    AttemptedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    ResolvedAt DATETIME2 NULL,
    
    CONSTRAINT FK_FailedInventory FOREIGN KEY (InventoryId) REFERENCES InventoryUpload(InventoryId)
);

CREATE INDEX idx_FailedInventory_InventoryId ON FailedInventorySubmissions(InventoryId);
CREATE INDEX idx_FailedInventory_AttemptedAt ON FailedInventorySubmissions(AttemptedAt);

-- Rename ProcessedInventory to SubmittedInventory for clarity
EXEC sp_rename 'ProcessedInventory', 'SubmittedInventory';

-- Add table to track Sage ERP imports
CREATE TABLE SageInvoiceImports (
    ImportId INT IDENTITY(1,1) PRIMARY KEY,
    SageInvoiceId NVARCHAR(100),
    InvoiceId INT,
    ImportedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    ProcessedAt DATETIME2 NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'PENDING', -- 'PENDING', 'PROCESSED', 'FAILED'
    MRAInvoiceNumber NVARCHAR(100),
    MRAResponse NVARCHAR(MAX),
    
    CONSTRAINT FK_SageImport_Invoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId),
    CONSTRAINT CK_ImportStatus CHECK (Status IN ('PENDING', 'PROCESSED', 'FAILED'))
);

CREATE INDEX idx_SageImport_Status ON SageInvoiceImports(Status);
CREATE INDEX idx_SageImport_ImportedAt ON SageInvoiceImports(ImportedAt);