-- =====================================================
-- MRA Invoice System - Database Schema
-- Created: 2026-02-13
-- =====================================================

-- Drop existing tables if they exist (for fresh setup)
IF OBJECT_ID('dbo.InvoiceSummary', 'U') IS NOT NULL DROP TABLE dbo.InvoiceSummary;
IF OBJECT_ID('dbo.InvoiceTaxBreakdown', 'U') IS NOT NULL DROP TABLE dbo.InvoiceTaxBreakdown;
IF OBJECT_ID('dbo.InvoiceLineItems', 'U') IS NOT NULL DROP TABLE dbo.InvoiceLineItems;
IF OBJECT_ID('dbo.InvoiceHeader', 'U') IS NOT NULL DROP TABLE dbo.InvoiceHeader;
IF OBJECT_ID('dbo.ProcessedInvoices', 'U') IS NOT NULL DROP TABLE dbo.ProcessedInvoices;
IF OBJECT_ID('dbo.InventoryUpload', 'U') IS NOT NULL DROP TABLE dbo.InventoryUpload;
IF OBJECT_ID('dbo.ProcessedInventory', 'U') IS NOT NULL DROP TABLE dbo.ProcessedInventory;
IF OBJECT_ID('dbo.AuditLog', 'U') IS NOT NULL DROP TABLE dbo.AuditLog;

-- =====================================================
-- TABLE: InvoiceHeader
-- Purpose: Store invoice header information from Sage ACCPAC ERP
-- =====================================================
CREATE TABLE InvoiceHeader (
    InvoiceId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceNumber NVARCHAR(50) NOT NULL UNIQUE,
    InvoiceDateTime DATETIME2 NOT NULL,
    SellerTIN NVARCHAR(20) NOT NULL,
    BuyerTIN NVARCHAR(20) NULL,
    BuyerName NVARCHAR(200) NULL,
    BuyerAuthorizationCode NVARCHAR(100) NULL,
    SiteId NVARCHAR(100) NOT NULL,
    GlobalConfigVersion INT NOT NULL,
    TaxpayerConfigVersion INT NOT NULL,
    TerminalConfigVersion INT NOT NULL,
    IsReliefSupply BIT NOT NULL DEFAULT 0,
    Vat5CertificateId INT NULL,
    Vat5ProjectNumber NVARCHAR(100) NULL,
    Vat5CertificateNumber NVARCHAR(100) NULL,
    Vat5Quantity DECIMAL(18,2) NULL,
    PaymentMethod NVARCHAR(50) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    UpdatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT CK_PaymentMethod CHECK (PaymentMethod IN ('CASH', 'CARD', 'CHEQUE', 'BANK_TRANSFER', 'OTHER'))
);

CREATE INDEX idx_InvoiceHeader_SellerTIN ON InvoiceHeader(SellerTIN);
CREATE INDEX idx_InvoiceHeader_InvoiceDateTime ON InvoiceHeader(InvoiceDateTime);
CREATE INDEX idx_InvoiceHeader_Status ON InvoiceHeader(CreatedAt);

-- =====================================================
-- TABLE: InvoiceLineItems
-- Purpose: Store invoice line items
-- =====================================================
CREATE TABLE InvoiceLineItems (
    LineItemId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProductCode NVARCHAR(50) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    Quantity DECIMAL(18,2) NOT NULL,
    Discount DECIMAL(18,2) NOT NULL DEFAULT 0,
    Total DECIMAL(18,2) NOT NULL,
    TotalVAT DECIMAL(18,2) NOT NULL,
    TaxRateId NVARCHAR(10) NOT NULL,
    IsProduct BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT FK_LineItems_Invoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId) ON DELETE CASCADE
);

CREATE INDEX idx_LineItems_InvoiceId ON InvoiceLineItems(InvoiceId);
CREATE INDEX idx_LineItems_ProductCode ON InvoiceLineItems(ProductCode);

-- =====================================================
-- TABLE: InvoiceTaxBreakdown
-- Purpose: Store tax breakdown per rate ID
-- =====================================================
CREATE TABLE InvoiceTaxBreakdown (
    TaxBreakdownId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    RateId NVARCHAR(10) NOT NULL,
    TaxableAmount DECIMAL(18,2) NOT NULL,
    TaxAmount DECIMAL(18,2) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT FK_TaxBreakdown_Invoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId) ON DELETE CASCADE
);

CREATE INDEX idx_TaxBreakdown_InvoiceId ON InvoiceTaxBreakdown(InvoiceId);

-- =====================================================
-- TABLE: InvoiceSummary
-- Purpose: Store invoice summary (totals)
-- =====================================================
CREATE TABLE InvoiceSummary (
    SummaryId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL UNIQUE,
    TotalVAT DECIMAL(18,2) NOT NULL,
    OfflineSignature NVARCHAR(MAX) NULL,
    InvoiceTotal DECIMAL(18,2) NOT NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT FK_Summary_Invoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId) ON DELETE CASCADE
);

CREATE INDEX idx_Summary_InvoiceId ON InvoiceSummary(InvoiceId);

-- =====================================================
-- TABLE: ProcessedInvoices
-- Purpose: Archive of successfully submitted invoices to MRA
-- =====================================================
CREATE TABLE ProcessedInvoices (
    ProcessedInvoiceId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    InvoiceNumber NVARCHAR(50) NOT NULL,
    InvoiceDateTime DATETIME2 NOT NULL,
    SellerTIN NVARCHAR(20) NOT NULL,
    BuyerTIN NVARCHAR(20) NULL,
    BuyerName NVARCHAR(200) NULL,
    BuyerAuthorizationCode NVARCHAR(100) NULL,
    SiteId NVARCHAR(100) NOT NULL,
    GlobalConfigVersion INT NOT NULL,
    TaxpayerConfigVersion INT NOT NULL,
    TerminalConfigVersion INT NOT NULL,
    IsReliefSupply BIT NOT NULL,
    PaymentMethod NVARCHAR(50) NOT NULL,
    MRAResponse NVARCHAR(MAX) NOT NULL,
    SubmittedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT UQ_ProcessedInvoiceNumber UNIQUE (InvoiceNumber)
);

CREATE INDEX idx_ProcessedInvoices_SellerTIN ON ProcessedInvoices(SellerTIN);
CREATE INDEX idx_ProcessedInvoices_SubmittedAt ON ProcessedInvoices(SubmittedAt);
CREATE INDEX idx_ProcessedInvoices_InvoiceDateTime ON ProcessedInvoices(InvoiceDateTime);

-- =====================================================
-- TABLE: InventoryUpload
-- Purpose: Store initial inventory uploads (pending submission to MRA)
-- =====================================================
CREATE TABLE InventoryUpload (
    InventoryId INT IDENTITY(1,1) PRIMARY KEY,
    TIN NVARCHAR(20) NOT NULL,
    BarCode NVARCHAR(50) NOT NULL UNIQUE,
    ProductName NVARCHAR(200) NOT NULL,
    ProductDescription NVARCHAR(500) NOT NULL,
    QuantityInStock DECIMAL(18,2) NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    CostPrice DECIMAL(18,2) NOT NULL,
    SellingPrice DECIMAL(18,2) NOT NULL,
    ReorderLevel DECIMAL(18,2) NOT NULL,
    OverQuantityStockLevel DECIMAL(18,2) NOT NULL,
    UploadedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT CK_Inventory_Prices CHECK (SellingPrice >= CostPrice AND UnitPrice > 0)
);

CREATE INDEX idx_InventoryUpload_TIN ON InventoryUpload(TIN);
CREATE INDEX idx_InventoryUpload_BarCode ON InventoryUpload(BarCode);
CREATE INDEX idx_InventoryUpload_UploadedAt ON InventoryUpload(UploadedAt);

-- =====================================================
-- TABLE: ProcessedInventory
-- Purpose: Archive of successfully submitted inventory to MRA
-- =====================================================
CREATE TABLE ProcessedInventory (
    ProcessedInventoryId INT IDENTITY(1,1) PRIMARY KEY,
    InventoryId INT NOT NULL,
    TIN NVARCHAR(20) NOT NULL,
    BarCode NVARCHAR(50) NOT NULL,
    ProductName NVARCHAR(200) NOT NULL,
    ProductDescription NVARCHAR(500) NOT NULL,
    QuantityInStock DECIMAL(18,2) NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    CostPrice DECIMAL(18,2) NOT NULL,
    SellingPrice DECIMAL(18,2) NOT NULL,
    ReorderLevel DECIMAL(18,2) NOT NULL,
    OverQuantityStockLevel DECIMAL(18,2) NOT NULL,
    MRAResponse NVARCHAR(MAX) NOT NULL,
    SubmittedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT UQ_ProcessedBarCode UNIQUE (BarCode)
);

CREATE INDEX idx_ProcessedInventory_TIN ON ProcessedInventory(TIN);
CREATE INDEX idx_ProcessedInventory_SubmittedAt ON ProcessedInventory(SubmittedAt);

-- =====================================================
-- TABLE: AuditLog
-- Purpose: Track all system activities for compliance
-- =====================================================
CREATE TABLE AuditLog (
    AuditId INT IDENTITY(1,1) PRIMARY KEY,
    ActionType NVARCHAR(50) NOT NULL,
    EntityType NVARCHAR(50) NOT NULL,
    EntityId INT NULL,
    Description NVARCHAR(500) NOT NULL,
    OldValues NVARCHAR(MAX) NULL,
    NewValues NVARCHAR(MAX) NULL,
    PerformedBy NVARCHAR(100) NULL,
    IPAddress NVARCHAR(50) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    CONSTRAINT CK_ActionType CHECK (ActionType IN ('CREATE', 'UPDATE', 'DELETE', 'SUBMIT', 'ERROR', 'LOGIN'))
);

CREATE INDEX idx_AuditLog_EntityType ON AuditLog(EntityType);
CREATE INDEX idx_AuditLog_CreatedAt ON AuditLog(CreatedAt);
CREATE INDEX idx_AuditLog_ActionType ON AuditLog(ActionType);

-- =====================================================
-- Sample Data (Optional - for testing)
-- =====================================================

-- Insert sample tax rates configuration
-- This would typically come from the MRA activation response

-- Insert sample invoice for testing
/*
INSERT INTO InvoiceHeader (InvoiceNumber, InvoiceDateTime, SellerTIN, SiteId, GlobalConfigVersion, TaxpayerConfigVersion, TerminalConfigVersion, IsReliefSupply, PaymentMethod)
VALUES ('TEST-001', GETDATE(), '20197126', 'SITE-001', 1, 1, 1, 0, 'CASH');

INSERT INTO InvoiceLineItems (InvoiceId, ProductCode, Description, UnitPrice, Quantity, Discount, Total, TotalVAT, TaxRateId, IsProduct)
VALUES (1, '22028', 'CONSULTANCY SERVICES', 250000, 2, 0, 500000, 87500, 'A', 0);

INSERT INTO InvoiceTaxBreakdown (InvoiceId, RateId, TaxableAmount, TaxAmount)
VALUES (1, 'A', 412500, 87500);

INSERT INTO InvoiceSummary (InvoiceId, TotalVAT, InvoiceTotal)
VALUES (1, 87500, 500000);
*/

-- =====================================================
-- Database Statistics and Settings
-- =====================================================
ALTER DATABASE [MRA_InvoiceDB] SET RECOVERY SIMPLE;
ALTER DATABASE [MRA_InvoiceDB] SET AUTO_SHRINK OFF;

-- Enable query hints for better performance
-- Note: Ensure proper backups before running in production

PRINT 'Database schema created successfully!';
PRINT 'Tables created: 8';
PRINT '- InvoiceHeader';
PRINT '- InvoiceLineItems';
PRINT '- InvoiceTaxBreakdown';
PRINT '- InvoiceSummary';
PRINT '- ProcessedInvoices';
PRINT '- InventoryUpload';
PRINT '- ProcessedInventory';
PRINT '- AuditLog';