-- Add table to track failed invoice submissions
CREATE TABLE FailedInvoiceSubmissions (
    FailureId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ErrorMessage NVARCHAR(MAX) NOT NULL,
    AttemptedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    ResolvedAt DATETIME2 NULL,
    
    CONSTRAINT FK_FailedInvoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId)
);

CREATE INDEX idx_FailedInvoice_InvoiceId ON FailedInvoiceSubmissions(InvoiceId);
CREATE INDEX idx_FailedInvoice_AttemptedAt ON FailedInvoiceSubmissions(AttemptedAt);

-- Add table to track invoice processing history
CREATE TABLE InvoiceProcessingHistory (
    HistoryId INT IDENTITY(1,1) PRIMARY KEY,
    InvoiceId INT NOT NULL,
    ProcessedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    Status NVARCHAR(50) NOT NULL, -- 'SUCCESS', 'FAILED', 'PENDING'
    MRAInvoiceNumber NVARCHAR(100),
    MRAResponse NVARCHAR(MAX),
    ErrorMessage NVARCHAR(MAX),
    
    CONSTRAINT FK_HistoryInvoice FOREIGN KEY (InvoiceId) REFERENCES InvoiceHeader(InvoiceId),
    CONSTRAINT CK_Status CHECK (Status IN ('SUCCESS', 'FAILED', 'PENDING'))
);

CREATE INDEX idx_ProcessingHistory_InvoiceId ON InvoiceProcessingHistory(InvoiceId);
CREATE INDEX idx_ProcessingHistory_ProcessedAt ON InvoiceProcessingHistory(ProcessedAt);
CREATE INDEX idx_ProcessingHistory_Status ON InvoiceProcessingHistory(Status);