require('dotenv').config();
const app = require('./src/app');
const logger = require('./src/utils/logger');
const { startInvoiceProcessor } = require('./src/jobs/invoiceProcessor');

const PORT = process.env.SERVER_PORT || 3000;

const server = app.listen(PORT, () => {
  logger.info(`🚀 Server running on port ${PORT}`);
  logger.info(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`🔗 Access the app at http://localhost:${PORT}`);
  logger.info(`📋 Dashboard: http://localhost:${PORT}`);
  logger.info(`📦 Inventory Form: http://localhost:${PORT}/inventory-form`);
  logger.info(`🔌 Terminal Activation: http://localhost:${PORT}/activate-terminal`);
  logger.info(`💊 Health Check: http://localhost:${PORT}/health`);
  console.log('\n✅ System is ready for use!\n');

  // Start invoice processor job
  startInvoiceProcessor();
});

// Handle unhandled rejections
process.on('unhandledRejection', (err) => {
  logger.error('💥 Unhandled Rejection:', err);
  server.close(() => {
    logger.error('Server closed due to unhandled rejection');
    process.exit(1);
  });
});

// Handle SIGTERM
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

// Handle SIGINT (Ctrl+C)
process.on('SIGINT', () => {
  logger.info('SIGINT signal received: closing HTTP server');
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

process.on('exit', (code) => {
  logger.info(`Process exiting with code ${code}`);
});

module.exports = server;