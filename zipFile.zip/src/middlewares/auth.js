const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const { getTerminalCreds } = require('../utils/terminalState');

/**
 * Verify terminal activation middleware
 */
const verifyTerminalActivation = (req, res, next) => {
  try {
    const creds = getTerminalCreds();
    if (!creds) {
      return res.status(400).json({
        success: false,
        message: 'Terminal not activated. Please activate terminal first.'
      });
    }

    req.terminalCreds = creds;
    next();
  } catch (err) {
    logger.error('Terminal verification error:', err);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

/**
 * Verify JWT token in Authorization header
 */
const verifyJWT = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Missing or invalid authorization header'
      });
    }

    const token = authHeader.slice(7);
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    logger.error('JWT verification error:', err);
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

module.exports = {
  verifyTerminalActivation,
  verifyJWT
};