const logger = require('../utils/logger');

/**
 * Simple in-memory rate limiter
 */
class RateLimiter {
  constructor(maxRequests = 100, windowMs = 60000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
    this.requests = new Map();
  }

  isLimited(key) {
    const now = Date.now();
    
    if (!this.requests.has(key)) {
      this.requests.set(key, []);
    }

    const timestamps = this.requests.get(key);
    
    // Remove old timestamps outside the window
    const validTimestamps = timestamps.filter(ts => now - ts < this.windowMs);
    this.requests.set(key, validTimestamps);

    // Check if limit exceeded
    if (validTimestamps.length >= this.maxRequests) {
      return true;
    }

    // Add current timestamp
    validTimestamps.push(now);
    return false;
  }
}

// Create rate limiters for different endpoints
const apiLimiter = new RateLimiter(100, 60000); // 100 requests per minute
const authLimiter = new RateLimiter(5, 60000); // 5 requests per minute for auth
const uploadLimiter = new RateLimiter(10, 60000); // 10 requests per minute for uploads

/**
 * General API rate limiter middleware
 */
const rateLimitAPI = (req, res, next) => {
  const key = `${req.ip}-api`;
  
  if (apiLimiter.isLimited(key)) {
    logger.warn(`Rate limit exceeded for ${key}`);
    return res.status(429).json({
      success: false,
      message: 'Too many requests, please try again later'
    });
  }

  next();
};

/**
 * Authentication rate limiter middleware
 */
const rateLimitAuth = (req, res, next) => {
  const key = `${req.ip}-auth`;
  
  if (authLimiter.isLimited(key)) {
    logger.warn(`Auth rate limit exceeded for ${key}`);
    return res.status(429).json({
      success: false,
      message: 'Too many authentication attempts, please try again later'
    });
  }

  next();
};

/**
 * Upload rate limiter middleware
 */
const rateLimitUpload = (req, res, next) => {
  const key = `${req.ip}-upload`;
  
  if (uploadLimiter.isLimited(key)) {
    logger.warn(`Upload rate limit exceeded for ${key}`);
    return res.status(429).json({
      success: false,
      message: 'Too many uploads, please try again later'
    });
  }

  next();
};

module.exports = {
  rateLimitAPI,
  rateLimitAuth,
  rateLimitUpload,
  RateLimiter
};