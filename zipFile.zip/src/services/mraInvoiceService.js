const mraClient = require('../config/mraApi');
const logger = require('../utils/logger');
const { getTerminalCreds } = require('../utils/terminalState');
const { generateInvoiceNumber } = require('../utils/invoiceNumberGenerator');
const invoiceModel = require('../models/invoiceModel');
const { executeQuery, sql } = require('../config/database');

/**
 * Submit invoice to MRA
 * @param {object} invoiceData
 * @param {number} transactionCount
 * @returns {object}
 */
async function submitInvoice(invoiceData, transactionCount) {
  try {
    const creds = getTerminalCreds();
    if (!creds) {
      throw new Error('Terminal not activated');
    }

    logger.info('Preparing invoice for submission to MRA...');

    // Validate invoice data
    validateInvoiceData(invoiceData);

    // Generate invoice number
    const invoiceNumber = generateInvoiceNumber({
      taxpayerId: creds.taxpayerId,
      terminalPosition: creds.terminalPosition,
      transactionDate: invoiceData.invoiceHeader.invoiceDateTime,
      transactionCount
    });

    logger.info(`Generated invoice number: ${invoiceNumber}`);

    // Calculate taxable amount: sum of line totals - total VAT
    const lineItemsTotalBeforeTax = invoiceData.invoiceLineItems.reduce(
      (sum, item) => sum + (parseFloat(item.total) || 0),
      0
    );
    
    const totalVAT = parseFloat(invoiceData.invoiceSummary.totalVAT) || 0;
    const taxableAmount = lineItemsTotalBeforeTax - totalVAT;

    logger.info(`Taxable amount calculated: ${taxableAmount}`);

    // Construct MRA payload
    const payload = {
      invoiceHeader: {
        invoiceNumber,
        invoiceDateTime: invoiceData.invoiceHeader.invoiceDateTime,
        sellerTIN: creds.taxpayerId.toString(),
        buyerTIN: invoiceData.invoiceHeader.buyerTIN || '',
        buyerName: invoiceData.invoiceHeader.buyerName || '',
        buyerAuthorizationCode: invoiceData.invoiceHeader.buyerAuthorizationCode || '',
        siteId: invoiceData.invoiceHeader.siteId || creds.siteId,
        globalConfigVersion: creds.globalConfigVersion,
        taxpayerConfigVersion: creds.taxpayerConfigVersion,
        terminalConfigVersion: creds.terminalConfigVersion,
        isReliefSupply: invoiceData.invoiceHeader.isReliefSupply || false,
        vat5CertificateDetails: {
          id: invoiceData.invoiceHeader.vat5CertificateDetails?.id || 0,
          projectNumber: invoiceData.invoiceHeader.vat5CertificateDetails?.projectNumber || '',
          certificateNumber: invoiceData.invoiceHeader.vat5CertificateDetails?.certificateNumber || '',
          quantity: invoiceData.invoiceHeader.vat5CertificateDetails?.quantity || 0
        },
        paymentMethod: invoiceData.invoiceHeader.paymentMethod || 'CASH'
      },
      invoiceLineItems: invoiceData.invoiceLineItems.map((item, idx) => ({
        id: idx + 1,
        productCode: item.productCode,
        description: item.description,
        unitPrice: parseFloat(item.unitPrice),
        quantity: parseFloat(item.quantity),
        discount: parseFloat(item.discount || 0),
        total: parseFloat(item.total),
        totalVAT: parseFloat(item.totalVAT),
        taxRateId: item.taxRateId,
        isProduct: item.isProduct || false
      })),
      invoiceSummary: {
        taxBreakDown: invoiceData.invoiceTaxBreakdown.map((tb) => ({
          rateId: tb.rateId,
          taxableAmount: parseFloat(tb.taxableAmount),
          taxAmount: parseFloat(tb.taxAmount)
        })),
        levyBreakDown: invoiceData.invoiceSummary.levyBreakDown || [],
        totalVAT: totalVAT,
        offlineSignature: invoiceData.invoiceSummary.offlineSignature || '',
        invoiceTotal: invoiceData.invoiceLineItems.reduce((sum, item) => sum + parseFloat(item.total), 0)
      }
    };

    logger.info(`Submitting invoice ${invoiceNumber} to MRA...`);

    // Submit to MRA
    const response = await mraClient.post('/submit-sales-transaction', payload, {
      headers: {
        Authorization: `Bearer ${creds.jwtToken}`
      }
    });

    if (response.data?.statusCode === 1) {
      logger.info(`✅ Invoice ${invoiceNumber} submitted successfully to MRA`);

      // Move invoice to processed table
      if (invoiceData.invoiceHeader.invoiceId) {
        await markInvoiceAsProcessed(
          invoiceData.invoiceHeader.invoiceId,
          response.data,
          invoiceNumber
        );
      }

      return {
        success: true,
        invoiceNumber,
        mraResponse: response.data,
        submittedAt: new Date().toISOString()
      };
    } else {
      throw new Error(response.data?.remark || 'Invoice submission failed');
    }
  } catch (err) {
    logger.error('Invoice submission error:', err.message);
    throw err;
  }
}

/**
 * Validate invoice data structure
 * @param {object} invoiceData
 */
function validateInvoiceData(invoiceData) {
  const errors = [];

  if (!invoiceData.invoiceHeader) {
    errors.push('invoiceHeader is required');
  }

  if (!invoiceData.invoiceLineItems || invoiceData.invoiceLineItems.length === 0) {
    errors.push('At least one line item is required');
  }

  if (!invoiceData.invoiceSummary) {
    errors.push('invoiceSummary is required');
  }

  if (!invoiceData.invoiceTaxBreakdown || invoiceData.invoiceTaxBreakdown.length === 0) {
    errors.push('Tax breakdown is required');
  }

  // Validate line items
  if (invoiceData.invoiceLineItems) {
    invoiceData.invoiceLineItems.forEach((item, idx) => {
      if (!item.productCode) errors.push(`Line item ${idx + 1}: productCode is required`);
      if (!item.description) errors.push(`Line item ${idx + 1}: description is required`);
      if (!item.unitPrice || isNaN(item.unitPrice)) errors.push(`Line item ${idx + 1}: valid unitPrice is required`);
      if (!item.quantity || isNaN(item.quantity)) errors.push(`Line item ${idx + 1}: valid quantity is required`);
      if (!item.taxRateId) errors.push(`Line item ${idx + 1}: taxRateId is required`);
    });
  }

  if (errors.length > 0) {
    throw new Error(`Invoice validation failed:\n${errors.join('\n')}`);
  }
}

/**
 * Mark invoice as processed
 * @param {number} invoiceId
 * @param {object} mraResponse
 * @param {string} invoiceNumber
 */
async function markInvoiceAsProcessed(invoiceId, mraResponse, invoiceNumber) {
  try {
    const invoice = await invoiceModel.getInvoiceById(invoiceId);

    if (!invoice) {
      logger.warn(`Invoice ${invoiceId} not found for processing`);
      return;
    }

    await invoiceModel.moveToProcessed(invoiceId, mraResponse);
    logger.info(`Invoice ${invoiceNumber} moved to processed table`);
  } catch (err) {
    logger.error('Error marking invoice as processed:', err);
    // Don't throw - submission was successful, processing archival failed
  }
}

/**
 * Get pending invoices for submission
 * @returns {array}
 */
async function getPendingInvoices() {
  try {
    return await invoiceModel.getPendingInvoices();
  } catch (err) {
    logger.error('Error fetching pending invoices:', err);
    throw err;
  }
}

/**
 * Get invoice by ID
 * @param {number} invoiceId
 * @returns {object}
 */
async function getInvoiceById(invoiceId) {
  try {
    return await invoiceModel.getInvoiceById(invoiceId);
  } catch (err) {
    logger.error('Error fetching invoice:', err);
    throw err;
  }
}

/**
 * Get processed invoices
 * @returns {array}
 */
async function getProcessedInvoices() {
  try {
    return await invoiceModel.getProcessedInvoices();
  } catch (err) {
    logger.error('Error fetching processed invoices:', err);
    throw err;
  }
}

/**
 * Calculate invoice totals
 * @param {array} lineItems
 * @returns {object}
 */
function calculateInvoiceTotals(lineItems) {
  try {
    let subtotal = 0;
    let totalDiscount = 0;
    let totalVAT = 0;

    lineItems.forEach(item => {
      const itemSubtotal = parseFloat(item.quantity) * parseFloat(item.unitPrice);
      const itemDiscount = parseFloat(item.discount || 0);
      const itemVAT = parseFloat(item.totalVAT || 0);

      subtotal += itemSubtotal;
      totalDiscount += itemDiscount;
      totalVAT += itemVAT;
    });

    const taxableAmount = subtotal - totalDiscount;
    const invoiceTotal = subtotal - totalDiscount + totalVAT;

    return {
      subtotal,
      totalDiscount,
      taxableAmount,
      totalVAT,
      invoiceTotal
    };
  } catch (err) {
    logger.error('Error calculating invoice totals:', err);
    throw err;
  }
}

/**
 * Get transaction count for a specific date
 * @param {Date} date
 * @returns {number}
 */
async function getTransactionCountForDate(date) {
  try {
    const dateStr = date.toISOString().split('T')[0];
    const result = await executeQuery(
      `SELECT COUNT(*) as count FROM ProcessedInvoices WHERE CAST(SubmittedAt AS DATE) = @date`,
      [{ name: 'date', type: sql.Date, value: new Date(dateStr) }]
    );

    return (result[0]?.count || 0) + 1;
  } catch (err) {
    logger.error('Error getting transaction count:', err);
    return 1;
  }
}

/**
 * Resend invoice to MRA (for failed submissions)
 * @param {number} invoiceId
 * @returns {object}
 */
async function resendInvoice(invoiceId) {
  try {
    logger.info(`Attempting to resend invoice ${invoiceId}...`);

    const invoice = await getInvoiceById(invoiceId);

    if (!invoice) {
      throw new Error(`Invoice ${invoiceId} not found`);
    }

    const transactionCount = await getTransactionCountForDate(new Date(invoice.invoiceHeader.InvoiceDateTime));

    const result = await submitInvoice(
      {
        invoiceHeader: {
          invoiceNumber: invoice.invoiceHeader.InvoiceNumber,
          invoiceDateTime: invoice.invoiceHeader.InvoiceDateTime,
          sellerTIN: invoice.invoiceHeader.SellerTIN,
          buyerTIN: invoice.invoiceHeader.BuyerTIN,
          buyerName: invoice.invoiceHeader.BuyerName,
          buyerAuthorizationCode: invoice.invoiceHeader.BuyerAuthorizationCode,
          siteId: invoice.invoiceHeader.SiteId,
          globalConfigVersion: invoice.invoiceHeader.GlobalConfigVersion,
          taxpayerConfigVersion: invoice.invoiceHeader.TaxpayerConfigVersion,
          terminalConfigVersion: invoice.invoiceHeader.TerminalConfigVersion,
          isReliefSupply: invoice.invoiceHeader.IsReliefSupply,
          vat5CertificateDetails: {
            id: invoice.invoiceHeader.Vat5CertificateId,
            projectNumber: invoice.invoiceHeader.Vat5ProjectNumber,
            certificateNumber: invoice.invoiceHeader.Vat5CertificateNumber,
            quantity: invoice.invoiceHeader.Vat5Quantity
          },
          paymentMethod: invoice.invoiceHeader.PaymentMethod
        },
        invoiceLineItems: invoice.invoiceLineItems.map(li => ({
          productCode: li.ProductCode,
          description: li.Description,
          unitPrice: li.UnitPrice,
          quantity: li.Quantity,
          discount: li.Discount,
          total: li.Total,
          totalVAT: li.TotalVAT,
          taxRateId: li.TaxRateId,
          isProduct: li.IsProduct
        })),
        invoiceTaxBreakdown: invoice.invoiceTaxBreakdown.map(tb => ({
          rateId: tb.RateId,
          taxableAmount: tb.TaxableAmount,
          taxAmount: tb.TaxAmount
        })),
        invoiceSummary: {
          totalVAT: invoice.invoiceSummary.TotalVAT,
          offlineSignature: invoice.invoiceSummary.OfflineSignature,
          invoiceTotal: invoice.invoiceSummary.InvoiceTotal,
          levyBreakDown: []
        }
      },
      transactionCount
    );

    logger.info(`✅ Invoice ${invoiceId} resent successfully`);
    return result;
  } catch (err) {
    logger.error('Error resending invoice:', err);
    throw err;
  }
}

/**
 * Bulk submit invoices
 * @param {array} invoiceIds
 * @returns {array}
 */
async function bulkSubmitInvoices(invoiceIds) {
  try {
    logger.info(`Attempting to bulk submit ${invoiceIds.length} invoices...`);

    const results = [];
    let successCount = 0;
    let failureCount = 0;

    for (const invoiceId of invoiceIds) {
      try {
        const invoice = await getInvoiceById(invoiceId);
        const transactionCount = await getTransactionCountForDate(new Date(invoice.invoiceHeader.InvoiceDateTime));

        const result = await submitInvoice(
          {
            invoiceHeader: {
              invoiceNumber: invoice.invoiceHeader.InvoiceNumber,
              invoiceDateTime: invoice.invoiceHeader.InvoiceDateTime,
              sellerTIN: invoice.invoiceHeader.SellerTIN,
              buyerTIN: invoice.invoiceHeader.BuyerTIN,
              buyerName: invoice.invoiceHeader.BuyerName,
              buyerAuthorizationCode: invoice.invoiceHeader.BuyerAuthorizationCode,
              siteId: invoice.invoiceHeader.SiteId,
              globalConfigVersion: invoice.invoiceHeader.GlobalConfigVersion,
              taxpayerConfigVersion: invoice.invoiceHeader.TaxpayerConfigVersion,
              terminalConfigVersion: invoice.invoiceHeader.TerminalConfigVersion,
              isReliefSupply: invoice.invoiceHeader.IsReliefSupply,
              paymentMethod: invoice.invoiceHeader.PaymentMethod
            },
            invoiceLineItems: invoice.invoiceLineItems,
            invoiceTaxBreakdown: invoice.invoiceTaxBreakdown,
            invoiceSummary: {
              totalVAT: invoice.invoiceSummary.TotalVAT,
              offlineSignature: invoice.invoiceSummary.OfflineSignature,
              invoiceTotal: invoice.invoiceSummary.InvoiceTotal
            }
          },
          transactionCount
        );

        results.push({
          invoiceId,
          success: true,
          result
        });

        successCount++;
      } catch (err) {
        logger.error(`Failed to submit invoice ${invoiceId}:`, err.message);
        results.push({
          invoiceId,
          success: false,
          error: err.message
        });
        failureCount++;
      }
    }

    logger.info(`Bulk submission completed: ${successCount} succeeded, ${failureCount} failed`);

    return {
      total: invoiceIds.length,
      succeeded: successCount,
      failed: failureCount,
      results
    };
  } catch (err) {
    logger.error('Error in bulk submission:', err);
    throw err;
  }
}

module.exports = {
  submitInvoice,
  validateInvoiceData,
  getPendingInvoices,
  getInvoiceById,
  getProcessedInvoices,
  calculateInvoiceTotals,
  getTransactionCountForDate,
  resendInvoice,
  bulkSubmitInvoices
};