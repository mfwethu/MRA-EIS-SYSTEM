const logger = require('../utils/logger');
const mraInvoiceService = require('./mraInvoiceService');
const invoiceModel = require('../models/invoiceModel');
const { getTerminalCreds } = require('../utils/terminalState');
const { executeQuery, sql } = require('../config/database');
const mraClient = require('../config/mraApi');

const VAT_RATE = 0.175; // 17.5%

/**
 * Process pending invoices and submit to MRA
 */
async function processPendingInvoices() {
  try {
    logger.info('Starting to process pending invoices...');

    const pendingInvoices = await invoiceModel.getPendingInvoices();

    if (!pendingInvoices || pendingInvoices.length === 0) {
      logger.info('No pending invoices to process');
      return { processed: 0, successful: 0, failed: 0 };
    }

    const creds = getTerminalCreds();

    if (!creds) {
      logger.warn('Terminal not activated, cannot process invoices');
      return { processed: 0, successful: 0, failed: 0, error: 'Terminal not activated' };
    }

    let successful = 0;
    let failed = 0;
    const results = [];

    for (const invoiceHeader of pendingInvoices) {
      try {
        logger.info(`Processing invoice: ${invoiceHeader.InvoiceId}`);

        // Get complete invoice data
        const invoice = await invoiceModel.getInvoiceById(invoiceHeader.InvoiceId);

        if (!invoice) {
          logger.warn(`Invoice ${invoiceHeader.InvoiceId} not found`);
          failed++;
          continue;
        }

        // Get transaction count for the day
        const today = new Date().toISOString().split('T')[0];
        const countResult = await executeQuery(
          `SELECT COUNT(*) as count FROM ProcessedInvoices WHERE CAST(SubmittedAt AS DATE) = @date`,
          [{ name: 'date', type: sql.Date, value: new Date(today) }]
        );
        const transactionCount = (countResult[0]?.count || 0) + 1;

        // Format invoice data for submission
        const invoiceData = formatInvoiceForMRA(invoice, creds);

        // Submit to MRA with proper authentication
        const result = await submitInvoiceToMRA(invoiceData, creds, transactionCount);

        logger.info(`✅ Invoice ${invoiceHeader.InvoiceId} submitted successfully`);
        successful++;

        // Move to processed table
        await moveInvoiceToProcessed(invoiceHeader.InvoiceId, result);

        results.push({
          invoiceId: invoiceHeader.InvoiceId,
          success: true,
          invoiceNumber: result.invoiceNumber
        });
      } catch (err) {
        logger.error(`Failed to process invoice ${invoiceHeader.InvoiceId}:`, err);
        failed++;

        results.push({
          invoiceId: invoiceHeader.InvoiceId,
          success: false,
          error: err.message
        });

        // Log failure
        await logInvoiceSubmissionFailure(invoiceHeader.InvoiceId, err.message);
      }
    }

    logger.info(`Invoice processing completed: ${successful} successful, ${failed} failed`);

    return {
      processed: pendingInvoices.length,
      successful,
      failed,
      results
    };
  } catch (err) {
    logger.error('Error in processPendingInvoices:', err);
    throw err;
  }
}

/**
 * Format invoice from database to MRA API format with proper VAT calculations
 * VAT Rate: 17.5%
 * Taxable Amount = Sum of Line Items Total - Total VAT
 * 
 * Example:
 * Line Item Total = 1000
 * Taxable Amount = 1000 / (1 + 0.175) = 850.21
 * VAT = 1000 - 850.21 = 149.79
 */
function formatInvoiceForMRA(invoice, creds) {
  const header = invoice.invoiceHeader;
  const lineItems = invoice.invoiceLineItems;
  const summary = invoice.invoiceSummary;

  // Calculate totals correctly with 17.5% VAT
  // Sum all line item totals
  const lineItemsTotal = lineItems.reduce((sum, item) => sum + parseFloat(item.Total || 0), 0);

  // Calculate VAT: Total / (1 + VAT_RATE) gives us the base amount
  // Then VAT = Total - Base
  const baseAmount = lineItemsTotal / (1 + VAT_RATE);
  const totalVAT = lineItemsTotal - baseAmount;
  const taxableAmount = baseAmount; // This is the taxable amount

  logger.info(`
    Invoice VAT Calculation (17.5%):
    - Line Items Total: ${lineItemsTotal}
    - Base (Taxable) Amount: ${baseAmount.toFixed(2)}
    - VAT (17.5%): ${totalVAT.toFixed(2)}
    - Total: ${(baseAmount + totalVAT).toFixed(2)}
  `);

  return {
    invoiceHeader: {
      invoiceNumber: header.InvoiceNumber || 'PENDING',
      invoiceDateTime: new Date(header.InvoiceDateTime).toISOString(),
      sellerTIN: creds.taxpayerId.toString(),
      buyerTIN: header.BuyerTIN || '',
      buyerName: header.BuyerName || '',
      buyerAuthorizationCode: header.BuyerAuthorizationCode || '',
      siteId: creds.siteId || header.SiteId,
      globalConfigVersion: creds.globalConfigVersion,
      taxpayerConfigVersion: creds.taxpayerConfigVersion,
      terminalConfigVersion: creds.terminalConfigVersion,
      isReliefSupply: header.IsReliefSupply || false,
      vat5CertificateDetails: {
        id: header.Vat5CertificateId || 0,
        projectNumber: header.Vat5ProjectNumber || '',
        certificateNumber: header.Vat5CertificateNumber || '',
        quantity: header.Vat5Quantity || 0
      },
      paymentMethod: header.PaymentMethod || 'CASH'
    },
    invoiceLineItems: lineItems.map((item, idx) => {
      const itemTotal = parseFloat(item.Total || 0);
      const itemBase = itemTotal / (1 + VAT_RATE);
      const itemVAT = itemTotal - itemBase;

      return {
        id: idx + 1,
        productCode: item.ProductCode,
        description: item.Description,
        unitPrice: parseFloat(item.UnitPrice),
        quantity: parseFloat(item.Quantity),
        discount: parseFloat(item.Discount || 0),
        total: itemTotal,
        totalVAT: itemVAT, // 17.5% VAT
        taxRateId: item.TaxRateId || 'A',
        isProduct: item.IsProduct || false
      };
    }),
    invoiceSummary: {
      taxBreakDown: [{
        rateId: 'A',
        taxableAmount: taxableAmount, // Base amount (before VAT)
        taxAmount: totalVAT // VAT amount (17.5%)
      }],
      levyBreakDown: [],
      totalVAT: totalVAT,
      offlineSignature: summary.OfflineSignature || '',
      invoiceTotal: lineItemsTotal
    }
  };
}

/**
 * Calculate line item with 17.5% VAT
 * Used for preparing line items
 */
function calculateLineItemVAT(unitPrice, quantity, discount = 0) {
  const subtotal = (unitPrice * quantity) - discount;
  const baseAmount = subtotal / (1 + VAT_RATE);
  const vatAmount = subtotal - baseAmount;

  return {
    subtotal,
    baseAmount,
    vatAmount,
    total: subtotal
  };
}

/**
 * Submit invoice to MRA with JWT authentication from terminal credentials
 */
async function submitInvoiceToMRA(invoiceData, creds, transactionCount) {
  try {
    logger.info('Submitting invoice to MRA with JWT authentication...');
    logger.info(`Using TIN: ${creds.taxpayerId}`);
    logger.info(`Authorization: Bearer ${creds.jwtToken.substring(0, 20)}...`);

    // Prepare the request with Bearer token from activate-terminal response
    const response = await mraClient.post('/submit-sales-transaction', invoiceData, {
      headers: {
        'Authorization': `Bearer ${creds.jwtToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.data?.statusCode === 1) {
      logger.info('✅ Invoice accepted by MRA');
      return {
        success: true,
        invoiceNumber: invoiceData.invoiceHeader.invoiceNumber,
        mraResponse: response.data
      };
    } else {
      throw new Error(response.data?.remark || 'MRA rejected invoice');
    }
  } catch (err) {
    logger.error('Error submitting to MRA:', err.message);
    throw err;
  }
}

/**
 * Move invoice to processed table
 */
async function moveInvoiceToProcessed(invoiceId, result) {
  try {
    const invoice = await invoiceModel.getInvoiceById(invoiceId);

    if (!invoice) {
      throw new Error('Invoice not found');
    }

    const header = invoice.invoiceHeader;

    await executeQuery(
      `INSERT INTO ProcessedInvoices 
       (InvoiceId, InvoiceNumber, InvoiceDateTime, SellerTIN, BuyerTIN, BuyerName, 
        BuyerAuthorizationCode, SiteId, GlobalConfigVersion, TaxpayerConfigVersion, 
        TerminalConfigVersion, IsReliefSupply, PaymentMethod, MRAResponse)
       VALUES 
       (@invoiceId, @invoiceNumber, @invoiceDateTime, @sellerTIN, @buyerTIN, @buyerName,
        @buyerAuthorizationCode, @siteId, @globalConfigVersion, @taxpayerConfigVersion,
        @terminalConfigVersion, @isReliefSupply, @paymentMethod, @mraResponse)`,
      [
        { name: 'invoiceId', type: sql.Int, value: invoiceId },
        { name: 'invoiceNumber', type: sql.NVarChar, value: header.InvoiceNumber },
        { name: 'invoiceDateTime', type: sql.DateTime2, value: new Date(header.InvoiceDateTime) },
        { name: 'sellerTIN', type: sql.NVarChar, value: header.SellerTIN },
        { name: 'buyerTIN', type: sql.NVarChar, value: header.BuyerTIN },
        { name: 'buyerName', type: sql.NVarChar, value: header.BuyerName },
        { name: 'buyerAuthorizationCode', type: sql.NVarChar, value: header.BuyerAuthorizationCode },
        { name: 'siteId', type: sql.NVarChar, value: header.SiteId },
        { name: 'globalConfigVersion', type: sql.Int, value: header.GlobalConfigVersion },
        { name: 'taxpayerConfigVersion', type: sql.Int, value: header.TaxpayerConfigVersion },
        { name: 'terminalConfigVersion', type: sql.Int, value: header.TerminalConfigVersion },
        { name: 'isReliefSupply', type: sql.Bit, value: header.IsReliefSupply ? 1 : 0 },
        { name: 'paymentMethod', type: sql.NVarChar, value: header.PaymentMethod },
        { name: 'mraResponse', type: sql.NVarChar, value: JSON.stringify(result.mraResponse) }
      ]
    );

    // Delete from pending
    await invoiceModel.deleteInvoice(invoiceId);

    logger.info(`Moved invoice ${invoiceId} to processed`);
  } catch (err) {
    logger.error('Error moving invoice to processed:', err);
    throw err;
  }
}

/**
 * Log invoice submission failure
 */
async function logInvoiceSubmissionFailure(invoiceId, errorMessage) {
  try {
    await executeQuery(
      `INSERT INTO FailedInvoiceSubmissions (InvoiceId, ErrorMessage, AttemptedAt)
       VALUES (@invoiceId, @errorMessage, GETDATE())`,
      [
        { name: 'invoiceId', type: sql.Int, value: invoiceId },
        { name: 'errorMessage', type: sql.NVarChar, value: errorMessage }
      ]
    );
  } catch (err) {
    logger.error('Error logging invoice failure:', err);
  }
}

module.exports = {
  processPendingInvoices,
  formatInvoiceForMRA,
  submitInvoiceToMRA,
  calculateLineItemVAT,
  VAT_RATE
};