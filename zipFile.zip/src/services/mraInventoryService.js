const mraClient = require('../config/mraApi');
const logger = require('../utils/logger');
const { getTerminalCreds } = require('../utils/terminalState');
const inventoryModel = require('../models/inventoryModel');

/**
 * Upload initial inventory to MRA
 * @param {array} products
 * @param {boolean} isLastBatch
 * @returns {object}
 */
async function uploadInitialInventory(products, isLastBatch = false) {
  try {
    const creds = getTerminalCreds();
    if (!creds) {
      throw new Error('Terminal not activated');
    }

    logger.info(`Preparing to upload ${products.length} products to MRA...`);

    // Validate products
    validateProducts(products);

    const payload = {
      TIN: creds.taxpayerId.toString(),
      IsLastBatch: isLastBatch,
      Products: products.map((p) => ({
        BarCode: p.barCode.toString().trim(),
        ProductName: p.productName.toString().trim(),
        ProductDescription: p.productDescription.toString().trim(),
        QuantityInStock: parseFloat(p.quantityInStock),
        UnitPrice: parseFloat(p.unitPrice),
        CostPrice: parseFloat(p.costPrice),
        SellingPrice: parseFloat(p.sellingPrice),
        ReorderLevel: parseFloat(p.reorderLevel),
        OverQuantityStockLevel: parseFloat(p.overQuantityStockLevel)
      }))
    };

    logger.info(`Uploading inventory batch to MRA (LastBatch: ${isLastBatch})...`);

    const response = await mraClient.post('/utilities/taxpayer-initial-inventory-upload', payload, {
      headers: {
        Authorization: `Bearer ${creds.jwtToken}`
      }
    });

    if (response.data?.statusCode === 1) {
      logger.info(`✅ Inventory batch uploaded successfully to MRA (${products.length} items)`);

      return {
        success: true,
        itemCount: products.length,
        isLastBatch,
        mraResponse: response.data,
        submittedAt: new Date().toISOString()
      };
    } else {
      throw new Error(response.data?.remark || 'Inventory upload failed');
    }
  } catch (err) {
    logger.error('Inventory upload error:', err.message);
    throw err;
  }
}

/**
 * Validate products array
 * @param {array} products
 */
function validateProducts(products) {
  const errors = [];

  if (!Array.isArray(products) || products.length === 0) {
    throw new Error('Products array is required and must not be empty');
  }

  products.forEach((product, idx) => {
    if (!product.barCode) errors.push(`Product ${idx + 1}: barCode is required`);
    if (!product.productName) errors.push(`Product ${idx + 1}: productName is required`);
    if (!product.productDescription) errors.push(`Product ${idx + 1}: productDescription is required`);
    if (isNaN(product.quantityInStock)) errors.push(`Product ${idx + 1}: valid quantityInStock is required`);
    if (isNaN(product.unitPrice)) errors.push(`Product ${idx + 1}: valid unitPrice is required`);
    if (isNaN(product.costPrice)) errors.push(`Product ${idx + 1}: valid costPrice is required`);
    if (isNaN(product.sellingPrice)) errors.push(`Product ${idx + 1}: valid sellingPrice is required`);
    if (isNaN(product.reorderLevel)) errors.push(`Product ${idx + 1}: valid reorderLevel is required`);
    if (isNaN(product.overQuantityStockLevel)) errors.push(`Product ${idx + 1}: valid overQuantityStockLevel is required`);

    // Business logic validation
    if (parseFloat(product.sellingPrice) < parseFloat(product.costPrice)) {
      errors.push(`Product ${idx + 1}: sellingPrice cannot be less than costPrice`);
    }

    if (parseFloat(product.unitPrice) <= 0) {
      errors.push(`Product ${idx + 1}: unitPrice must be greater than 0`);
    }
  });

  if (errors.length > 0) {
    throw new Error(`Product validation failed:\n${errors.join('\n')}`);
  }
}

/**
 * Save inventory upload to database
 * @param {array} products
 * @param {boolean} isLastBatch
 * @returns {array}
 */
async function saveInventoryUpload(products, isLastBatch) {
  try {
    const creds = getTerminalCreds();

    if (!creds) {
      throw new Error('Terminal not activated');
    }

    logger.info(`Saving ${products.length} inventory items to database...`);

    const inventoryIds = [];

    for (const product of products) {
      const inventoryId = await inventoryModel.createInventory(
        creds.taxpayerId.toString(),
        product
      );
      inventoryIds.push(inventoryId);
    }

    logger.info(`Saved ${inventoryIds.length} inventory items`);
    return inventoryIds;
  } catch (err) {
    logger.error('Error saving inventory:', err);
    throw err;
  }
}

/**
 * Get pending inventory items
 * @returns {array}
 */
async function getPendingInventory() {
  try {
    return await inventoryModel.getPendingInventory();
  } catch (err) {
    logger.error('Error fetching pending inventory:', err);
    throw err;
  }
}

/**
 * Get processed inventory items
 * @returns {array}
 */
async function getProcessedInventory() {
  try {
    return await inventoryModel.getProcessedInventory();
  } catch (err) {
    logger.error('Error fetching processed inventory:', err);
    throw err;
  }
}

/**
 * Get inventory by ID
 * @param {number} inventoryId
 * @returns {object}
 */
async function getInventoryById(inventoryId) {
  try {
    return await inventoryModel.getInventoryById(inventoryId);
  } catch (err) {
    logger.error('Error fetching inventory:', err);
    throw err;
  }
}

/**
 * Check if barcode exists
 * @param {string} barCode
 * @returns {boolean}
 */
async function barcodeExists(barCode) {
  try {
    const inventory = await inventoryModel.getInventoryByBarcode(barCode);
    return !!inventory;
  } catch (err) {
    logger.error('Error checking barcode:', err);
    throw err;
  }
}

/**
 * Upload inventory in batches
 * @param {array} products
 * @param {number} batchSize
 * @returns {object}
 */
async function uploadInBatches(products, batchSize = 100) {
  try {
    logger.info(`Uploading ${products.length} products in batches of ${batchSize}...`);

    const results = [];
    const batches = [];

    // Split products into batches
    for (let i = 0; i < products.length; i += batchSize) {
      batches.push(products.slice(i, i + batchSize));
    }

    let successCount = 0;
    let failureCount = 0;

    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      const isLastBatch = i === batches.length - 1;

      try {
        logger.info(`Uploading batch ${i + 1} of ${batches.length} (${batch.length} items, LastBatch: ${isLastBatch})...`);

        // Save to database
        const inventoryIds = await saveInventoryUpload(batch, isLastBatch);

        // Upload to MRA
        const result = await uploadInitialInventory(batch, isLastBatch);

        // Move to processed
        await inventoryModel.moveToProcessed(inventoryIds, result.mraResponse);

        results.push({
          batchNumber: i + 1,
          itemCount: batch.length,
          success: true,
          result
        });

        successCount += batch.length;
        logger.info(`✅ Batch ${i + 1} uploaded successfully`);
      } catch (err) {
        logger.error(`Error uploading batch ${i + 1}:`, err.message);
        results.push({
          batchNumber: i + 1,
          itemCount: batch.length,
          success: false,
          error: err.message
        });
        failureCount += batch.length;
      }

      // Add delay between batches
      if (!isLastBatch) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    logger.info(`Batch upload completed: ${successCount} succeeded, ${failureCount} failed`);

    return {
      totalItems: products.length,
      totalBatches: batches.length,
      succeededItems: successCount,
      failedItems: failureCount,
      results
    };
  } catch (err) {
    logger.error('Error in batch upload:', err);
    throw err;
  }
}

/**
 * Resend inventory to MRA (for failed submissions)
 * @param {array} inventoryIds
 * @returns {object}
 */
async function resendInventory(inventoryIds) {
  try {
    logger.info(`Attempting to resend ${inventoryIds.length} inventory items...`);

    const products = [];

    for (const inventoryId of inventoryIds) {
      const item = await getInventoryById(inventoryId);
      if (item) {
        products.push({
          barCode: item.BarCode,
          productName: item.ProductName,
          productDescription: item.ProductDescription,
          quantityInStock: item.QuantityInStock,
          unitPrice: item.UnitPrice,
          costPrice: item.CostPrice,
          sellingPrice: item.SellingPrice,
          reorderLevel: item.ReorderLevel,
          overQuantityStockLevel: item.OverQuantityStockLevel
        });
      }
    }

    if (products.length === 0) {
      throw new Error('No inventory items found for resend');
    }

    const result = await uploadInitialInventory(products, true);

    logger.info(`✅ Resent ${products.length} inventory items successfully`);
    return result;
  } catch (err) {
    logger.error('Error resending inventory:', err);
    throw err;
  }
}

/**
 * Calculate inventory value
 * @param {array} inventoryItems
 * @returns {object}
 */
function calculateInventoryValue(inventoryItems) {
  try {
    let totalValue = 0;
    let totalCost = 0;
    let totalQuantity = 0;

    inventoryItems.forEach(item => {
      const value = parseFloat(item.SellingPrice || item.UnitPrice) * parseFloat(item.QuantityInStock);
      const cost = parseFloat(item.CostPrice) * parseFloat(item.QuantityInStock);
      const qty = parseFloat(item.QuantityInStock);

      totalValue += value;
      totalCost += cost;
      totalQuantity += qty;
    });

    const profit = totalValue - totalCost;
    const profitMargin = totalValue > 0 ? (profit / totalValue) * 100 : 0;

    return {
      totalQuantity,
      totalCost,
      totalValue,
      profit,
      profitMargin: profitMargin.toFixed(2)
    };
  } catch (err) {
    logger.error('Error calculating inventory value:', err);
    throw err;
  }
}

/**
 * Get inventory summary statistics
 * @returns {object}
 */
async function getInventorySummary() {
  try {
    const pendingItems = await getPendingInventory();
    const processedItems = await getProcessedInventory();

    const pendingValue = calculateInventoryValue(pendingItems);
    const processedValue = calculateInventoryValue(processedItems);

    return {
      pending: {
        itemCount: pendingItems.length,
        ...pendingValue
      },
      processed: {
        itemCount: processedItems.length,
        ...processedValue
      },
      total: {
        itemCount: pendingItems.length + processedItems.length,
        totalQuantity: pendingValue.totalQuantity + processedValue.totalQuantity,
        totalCost: pendingValue.totalCost + processedValue.totalCost,
        totalValue: pendingValue.totalValue + processedValue.totalValue,
        profit: pendingValue.profit + processedValue.profit
      }
    };
  } catch (err) {
    logger.error('Error getting inventory summary:', err);
    throw err;
  }
}

module.exports = {
  uploadInitialInventory,
  validateProducts,
  saveInventoryUpload,
  getPendingInventory,
  getProcessedInventory,
  getInventoryById,
  barcodeExists,
  uploadInBatches,
  resendInventory,
  calculateInventoryValue,
  getInventorySummary
};