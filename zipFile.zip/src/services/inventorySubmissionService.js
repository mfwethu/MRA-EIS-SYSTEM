const logger = require('../utils/logger');
const inventoryModel = require('../models/inventoryModel');
const { getTerminalCreds } = require('../utils/terminalState');
const { executeQuery, sql } = require('../config/database');
const mraClient = require('../config/mraApi');

/**
 * Process pending inventory and submit to MRA
 */
async function processPendingInventory() {
  try {
    logger.info('Starting to process pending inventory...');

    const pendingInventory = await inventoryModel.getPendingInventory();

    if (!pendingInventory || pendingInventory.length === 0) {
      logger.info('No pending inventory to process');
      return { processed: 0, successful: 0, failed: 0 };
    }

    const creds = getTerminalCreds();

    if (!creds) {
      logger.warn('Terminal not activated, cannot process inventory');
      return { processed: 0, successful: 0, failed: 0, error: 'Terminal not activated' };
    }

    let successful = 0;
    let failed = 0;
    const results = [];
    const itemIds = [];

    // Group inventory items for batch processing
    for (const item of pendingInventory) {
      try {
        logger.info(`Processing inventory item: ${item.InventoryId}`);

        const isLastBatch = false; // Set to true when all items are processed

        const inventoryData = formatInventoryForMRA([item], isLastBatch);

        // Submit to MRA with JWT authentication
        const result = await submitInventoryToMRA(inventoryData, creds);

        logger.info(`✅ Inventory item ${item.InventoryId} submitted successfully`);
        successful++;
        itemIds.push(item.InventoryId);

        results.push({
          inventoryId: item.InventoryId,
          success: true,
          barCode: item.BarCode
        });
      } catch (err) {
        logger.error(`Failed to process inventory ${item.InventoryId}:`, err);
        failed++;

        results.push({
          inventoryId: item.InventoryId,
          success: false,
          error: err.message
        });

        // Log failure
        await logInventorySubmissionFailure(item.InventoryId, err.message);
      }
    }

    // Move successful items to submitted table
    if (itemIds.length > 0) {
      await moveInventoryToSubmitted(itemIds);
    }

    logger.info(`Inventory processing completed: ${successful} successful, ${failed} failed`);

    return {
      processed: pendingInventory.length,
      successful,
      failed,
      results
    };
  } catch (err) {
    logger.error('Error in processPendingInventory:', err);
    throw err;
  }
}

/**
 * Format inventory from database to MRA API format
 */
function formatInventoryForMRA(items, isLastBatch = false) {
  const creds = getTerminalCreds();

  return {
    TIN: creds.taxpayerId.toString(),
    IsLastBatch: isLastBatch,
    Products: items.map((item) => ({
      BarCode: item.BarCode.toString().trim(),
      ProductName: item.ProductName.toString().trim(),
      ProductDescription: item.ProductDescription.toString().trim(),
      QuantityInStock: parseFloat(item.QuantityInStock),
      UnitPrice: parseFloat(item.UnitPrice),
      CostPrice: parseFloat(item.CostPrice),
      SellingPrice: parseFloat(item.SellingPrice),
      ReorderLevel: parseFloat(item.ReorderLevel),
      OverQuantityStockLevel: parseFloat(item.OverQuantityStockLevel)
    }))
  };
}

/**
 * Submit inventory to MRA with JWT authentication
 */
async function submitInventoryToMRA(inventoryData, creds) {
  try {
    logger.info('Submitting inventory to MRA with JWT authentication...');

    const response = await mraClient.post('/utilities/taxpayer-initial-inventory-upload', inventoryData, {
      headers: {
        'Authorization': `Bearer ${creds.jwtToken}`,
        'Content-Type': 'application/json'
      }
    });

    if (response.data?.statusCode === 1) {
      logger.info('✅ Inventory accepted by MRA');
      return {
        success: true,
        mraResponse: response.data
      };
    } else {
      throw new Error(response.data?.remark || 'MRA rejected inventory');
    }
  } catch (err) {
    logger.error('Error submitting inventory to MRA:', err.message);
    throw err;
  }
}

/**
 * Move inventory to submitted table
 */
async function moveInventoryToSubmitted(inventoryIds) {
  try {
    for (const inventoryId of inventoryIds) {
      const item = await inventoryModel.getInventoryById(inventoryId);

      if (!item) {
        logger.warn(`Inventory ${inventoryId} not found`);
        continue;
      }

      // Insert into SubmittedInventory (renamed from ProcessedInventory)
      await executeQuery(
        `INSERT INTO SubmittedInventory 
         (InventoryId, TIN, BarCode, ProductName, ProductDescription, QuantityInStock,
          UnitPrice, CostPrice, SellingPrice, ReorderLevel, OverQuantityStockLevel, MRAResponse)
         VALUES 
         (@inventoryId, @tin, @barCode, @productName, @productDescription, @quantityInStock,
          @unitPrice, @costPrice, @sellingPrice, @reorderLevel, @overQuantityStockLevel, @mraResponse)`,
        [
          { name: 'inventoryId', type: sql.Int, value: inventoryId },
          { name: 'tin', type: sql.NVarChar, value: item.TIN },
          { name: 'barCode', type: sql.NVarChar, value: item.BarCode },
          { name: 'productName', type: sql.NVarChar, value: item.ProductName },
          { name: 'productDescription', type: sql.NVarChar, value: item.ProductDescription },
          { name: 'quantityInStock', type: sql.Decimal, value: item.QuantityInStock },
          { name: 'unitPrice', type: sql.Decimal, value: item.UnitPrice },
          { name: 'costPrice', type: sql.Decimal, value: item.CostPrice },
          { name: 'sellingPrice', type: sql.Decimal, value: item.SellingPrice },
          { name: 'reorderLevel', type: sql.Decimal, value: item.ReorderLevel },
          { name: 'overQuantityStockLevel', type: sql.Decimal, value: item.OverQuantityStockLevel },
          { name: 'mraResponse', type: sql.NVarChar, value: '{}' }
        ]
      );

      // Delete from pending
      await inventoryModel.deleteInventory(inventoryId);
    }

    logger.info(`Moved ${inventoryIds.length} items to submitted`);
  } catch (err) {
    logger.error('Error moving inventory to submitted:', err);
    throw err;
  }
}

/**
 * Log inventory submission failure
 */
async function logInventorySubmissionFailure(inventoryId, errorMessage) {
  try {
    await executeQuery(
      `INSERT INTO FailedInventorySubmissions (InventoryId, ErrorMessage, AttemptedAt)
       VALUES (@inventoryId, @errorMessage, GETDATE())`,
      [
        { name: 'inventoryId', type: sql.Int, value: inventoryId },
        { name: 'errorMessage', type: sql.NVarChar, value: errorMessage }
      ]
    );
  } catch (err) {
    logger.error('Error logging inventory failure:', err);
  }
}

module.exports = {
  processPendingInventory,
  formatInventoryForMRA,
  submitInventoryToMRA
};