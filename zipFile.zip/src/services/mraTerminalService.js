const mraClient = require('../config/mraApi');
const logger = require('../utils/logger');
const { saveTerminalCreds, getTerminalCreds } = require('../utils/terminalState');
const os = require('os');
const crypto = require('crypto');

/**
 * Activate terminal with MRA
 * @param {string} activationCode
 * @param {object} environment
 * @returns {object}
 */
async function activateTerminal(activationCode, environment) {
  try {
    logger.info(`Attempting to activate terminal with code: ${activationCode}`);

    const payload = {
      terminalActivationCode: activationCode,
      environment: environment || getDefaultEnvironment()
    };

    const response = await mraClient.post('/onboarding/activate-terminal', payload);

    if (response.data?.statusCode === 1 && response.data?.data?.activatedTerminal) {
      const terminalData = response.data.data;

      // Save credentials locally
      const credentialsToSave = {
        terminalId: terminalData.activatedTerminal.terminalId,
        terminalPosition: terminalData.activatedTerminal.terminalPosition,
        taxpayerId: terminalData.activatedTerminal.taxpayerId,
        activationDate: terminalData.activatedTerminal.activationDate,
        jwtToken: terminalData.activatedTerminal.terminalCredentials.jwtToken,
        secretKey: terminalData.activatedTerminal.terminalCredentials.secretKey,
        globalConfigVersion: terminalData.configuration.globalConfiguration.versionNo,
        taxpayerConfigVersion: terminalData.configuration.taxpayerConfiguration.versionNo,
        terminalConfigVersion: terminalData.configuration.terminalConfiguration.versionNo,
        siteId: terminalData.configuration.terminalConfiguration.terminalSite?.siteId,
        siteName: terminalData.configuration.terminalConfiguration.terminalSite?.siteName,
        configuration: {
          global: terminalData.configuration.globalConfiguration,
          taxpayer: terminalData.configuration.taxpayerConfiguration,
          terminal: terminalData.configuration.terminalConfiguration
        },
        activatedAt: new Date().toISOString()
      };

      saveTerminalCreds(credentialsToSave);

      logger.info('✅ Terminal activated successfully');
      logger.info(`Terminal ID: ${terminalData.activatedTerminal.terminalId}`);
      logger.info(`Taxpayer ID: ${terminalData.activatedTerminal.taxpayerId}`);

      return terminalData;
    } else {
      logger.warn('⚠️ Terminal activation returned unexpected status');
      const errorMessage = response.data?.remark || 'Terminal activation failed. Please check your activation code.';
      throw new Error(errorMessage);
    }
  } catch (err) {
    logger.error('Terminal activation error:', err.message);
    throw err;
  }
}

/**
 * Get default environment information for current system
 * @returns {object}
 */
function getDefaultEnvironment() {
  try {
    const platforms = {
      'win32': 'Windows',
      'darwin': 'macOS',
      'linux': 'Linux'
    };

    const platformName = platforms[process.platform] || 'Unknown';
    const osVersion = os.release();
    const macAddress = getLocalMacAddress() || '00-00-00-00-00-00';

    return {
      platform: {
        osName: `${platformName} (${os.arch()})`,
        osVersion: osVersion,
        osBuild: osVersion,
        macAddress: macAddress
      },
      pos: {
        productID: `MRA-desktop/${crypto.randomUUID()}`,
        productVersion: '1.0.0'
      }
    };
  } catch (err) {
    logger.error('Error creating default environment:', err);
    return {
      platform: {
        osName: 'Windows 11',
        osVersion: 'Current Version',
        osBuild: '11.901.2',
        macAddress: '00-00-00-00-00-00'
      },
      pos: {
        productID: `MRA-desktop/${crypto.randomUUID()}`,
        productVersion: '1.0.0'
      }
    };
  }
}

/**
 * Get local MAC address
 * @returns {string|null}
 */
function getLocalMacAddress() {
  try {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name]) {
        // Get the first non-internal IPv4 interface
        if (iface.family === 'IPv4' && !iface.internal) {
          return iface.mac;
        }
      }
    }
  } catch (err) {
    logger.warn('Could not retrieve MAC address:', err.message);
  }
  return null;
}

/**
 * Get current terminal activation status
 * @returns {object}
 */
function getTerminalStatus() {
  try {
    const creds = getTerminalCreds();
    
    return {
      isActivated: creds !== null,
      terminalId: creds?.terminalId || null,
      taxpayerId: creds?.taxpayerId || null,
      terminalPosition: creds?.terminalPosition || null,
      activationDate: creds?.activationDate || null,
      siteId: creds?.siteId || null,
      siteName: creds?.siteName || null,
      activatedAt: creds?.activatedAt || null
    };
  } catch (err) {
    logger.error('Error getting terminal status:', err);
    return {
      isActivated: false,
      error: err.message
    };
  }
}

/**
 * Get complete terminal details
 * @returns {object}
 */
function getTerminalDetails() {
  try {
    const creds = getTerminalCreds();

    if (!creds) {
      return null;
    }

    return {
      terminalId: creds.terminalId,
      taxpayerId: creds.taxpayerId,
      terminalPosition: creds.terminalPosition,
      activationDate: creds.activationDate,
      activatedAt: creds.activatedAt,
      siteId: creds.siteId,
      siteName: creds.siteName,
      jwtTokenPrefix: creds.jwtToken?.substring(0, 20) + '...', // Don't expose full token
      configuration: creds.configuration,
      globalConfigVersion: creds.globalConfigVersion,
      taxpayerConfigVersion: creds.taxpayerConfigVersion,
      terminalConfigVersion: creds.terminalConfigVersion
    };
  } catch (err) {
    logger.error('Error getting terminal details:', err);
    throw err;
  }
}

/**
 * Validate terminal credentials
 * @returns {boolean}
 */
function validateTerminalCredentials() {
  try {
    const creds = getTerminalCreds();

    if (!creds) {
      return false;
    }

    // Check if required fields exist
    const requiredFields = ['terminalId', 'taxpayerId', 'jwtToken', 'secretKey'];
    const isValid = requiredFields.every(field => creds[field]);

    if (!isValid) {
      logger.warn('Terminal credentials are incomplete');
      return false;
    }

    // Check if activation is recent (not older than 30 days)
    const activationDate = new Date(creds.activationDate);
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    if (activationDate < thirtyDaysAgo) {
      logger.warn('Terminal activation is older than 30 days');
    }

    return true;
  } catch (err) {
    logger.error('Error validating terminal credentials:', err);
    return false;
  }
}

/**
 * Check if terminal needs re-activation
 * @returns {boolean}
 */
function needsReactivation() {
  try {
    const creds = getTerminalCreds();

    if (!creds) {
      return true;
    }

    // Re-activate if older than 90 days
    const activationDate = new Date(creds.activationDate);
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);

    return activationDate < ninetyDaysAgo;
  } catch (err) {
    logger.error('Error checking reactivation need:', err);
    return false;
  }
}

/**
 * Get JWT token for API requests
 * @returns {string|null}
 */
function getJWTToken() {
  try {
    const creds = getTerminalCreds();
    return creds?.jwtToken || null;
  } catch (err) {
    logger.error('Error getting JWT token:', err);
    return null;
  }
}

/**
 * Get tax rates from terminal configuration
 * @returns {array}
 */
function getTaxRates() {
  try {
    const creds = getTerminalCreds();

    if (!creds?.configuration?.global?.taxrates) {
      logger.warn('Tax rates not found in configuration');
      return [];
    }

    return creds.configuration.global.taxrates;
  } catch (err) {
    logger.error('Error getting tax rates:', err);
    return [];
  }
}

/**
 * Get tax rate by ID
 * @param {string} rateId
 * @returns {object|null}
 */
function getTaxRateById(rateId) {
  try {
    const taxRates = getTaxRates();
    return taxRates.find(rate => rate.id === rateId) || null;
  } catch (err) {
    logger.error('Error getting tax rate:', err);
    return null;
  }
}

/**
 * Refresh terminal configuration
 * @returns {boolean}
 */
async function refreshTerminalConfiguration() {
  try {
    logger.info('Refreshing terminal configuration...');

    const creds = getTerminalCreds();

    if (!creds) {
      logger.warn('No terminal credentials found');
      return false;
    }

    // In a real scenario, you might call an MRA endpoint to get updated config
    // For now, we'll just validate existing config
    const isValid = validateTerminalCredentials();

    if (isValid) {
      logger.info('Terminal configuration is valid');
    } else {
      logger.warn('Terminal configuration validation failed');
    }

    return isValid;
  } catch (err) {
    logger.error('Error refreshing terminal configuration:', err);
    return false;
  }
}

module.exports = {
  activateTerminal,
  getDefaultEnvironment,
  getLocalMacAddress,
  getTerminalStatus,
  getTerminalDetails,
  validateTerminalCredentials,
  needsReactivation,
  getJWTToken,
  getTaxRates,
  getTaxRateById,
  refreshTerminalConfiguration
};