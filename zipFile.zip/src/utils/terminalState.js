const fs = require('fs');
const path = require('path');
const logger = require('./logger');

const storagePath = process.env.TERMINAL_STORAGE_PATH || './data/terminal-creds.json';

// Ensure data directory exists
const dataDir = path.dirname(storagePath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

/**
 * Save terminal credentials securely
 * @param {object} credentials
 */
function saveTerminalCreds(credentials) {
  try {
    const data = JSON.stringify(credentials, null, 2);
    fs.writeFileSync(storagePath, data, 'utf8');
    logger.info('✅ Terminal credentials saved');
  } catch (err) {
    logger.error('Error saving terminal credentials:', err);
    throw err;
  }
}

/**
 * Retrieve terminal credentials
 * @returns {object|null}
 */
function getTerminalCreds() {
  try {
    if (!fs.existsSync(storagePath)) {
      logger.warn('Terminal credentials file not found');
      return null;
    }

    const data = fs.readFileSync(storagePath, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    logger.error('Error reading terminal credentials:', err);
    return null;
  }
}

/**
 * Clear terminal credentials
 */
function clearTerminalCreds() {
  try {
    if (fs.existsSync(storagePath)) {
      fs.unlinkSync(storagePath);
      logger.info('Terminal credentials cleared');
    }
  } catch (err) {
    logger.error('Error clearing terminal credentials:', err);
    throw err;
  }
}

/**
 * Check if terminal is activated
 * @returns {boolean}
 */
function isTerminalActivated() {
  return getTerminalCreds() !== null;
}

module.exports = {
  saveTerminalCreds,
  getTerminalCreds,
  clearTerminalCreds,
  isTerminalActivated
};