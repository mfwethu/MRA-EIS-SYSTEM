const { toBase64 } = require('./base64Converter');
const logger = require('./logger');

/**
 * Convert date to Julian date number
 * @param {Date} dateObj
 * @returns {number}
 */
function toJulianDate(dateObj) {
  let year = dateObj.getFullYear();
  let month = dateObj.getMonth() + 1; // JavaScript months are 0-based
  const day = dateObj.getDate();

  // Adjust for January and February
  if (month <= 2) {
    year -= 1;
    month += 12;
  }

  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);

  const JD =
    Math.floor(365.25 * (year + 4716)) +
    Math.floor(30.6001 * (month + 1)) +
    day +
    B -
    1524;

  return JD;
}

/**
 * Generate invoice number following MRA specification
 * Format: Base64(TaxpayerID)-Base64(TerminalPosition)-Base64(JulianDate)-Base64(Count)
 *
 * @param {object} params
 * @param {number} params.taxpayerId - Taxpayer ID from terminal activation
 * @param {number} params.terminalPosition - Terminal position
 * @param {Date} params.transactionDate - Date of transaction
 * @param {number} params.transactionCount - Sequential count for the day
 * @returns {string}
 */
function generateInvoiceNumber({
  taxpayerId,
  terminalPosition,
  transactionDate,
  transactionCount
}) {
  try {
    if (!taxpayerId || !terminalPosition || !transactionDate || !transactionCount) {
      throw new Error('Missing required parameters for invoice number generation');
    }

    const julianDate = toJulianDate(new Date(transactionDate));

    const base64TaxpayerId = toBase64(taxpayerId);
    const base64TerminalPosition = toBase64(terminalPosition);
    const base64JulianDate = toBase64(julianDate);
    const base64Count = toBase64(transactionCount);

    const invoiceNumber = `${base64TaxpayerId}-${base64TerminalPosition}-${base64JulianDate}-${base64Count}`;

    logger.info(`Generated invoice number: ${invoiceNumber}`);
    return invoiceNumber;
  } catch (err) {
    logger.error('Error generating invoice number:', err);
    throw err;
  }
}

module.exports = {
  toJulianDate,
  generateInvoiceNumber
};