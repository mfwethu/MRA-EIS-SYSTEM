const logger = require('./logger');

const VAT_RATE = 0.175; // 17.5%

/**
 * Calculate VAT for a single line item
 * 
 * @param {number} unitPrice - Price per unit
 * @param {number} quantity - Number of units
 * @param {number} discount - Discount amount (optional)
 * @returns {object} Object with calculations
 * 
 * Example:
 * calculateLineVAT(1000, 1, 0)
 * Returns: { subtotal: 1000, baseAmount: 850.21, vatAmount: 149.79, total: 1000 }
 */
function calculateLineVAT(unitPrice, quantity, discount = 0) {
  const subtotal = (unitPrice * quantity) - discount;
  const baseAmount = subtotal / (1 + VAT_RATE);
  const vatAmount = subtotal - baseAmount;

  return {
    subtotal,
    baseAmount: Math.round(baseAmount * 100) / 100, // Round to 2 decimals
    vatAmount: Math.round(vatAmount * 100) / 100,
    total: subtotal,
    vatPercentage: VAT_RATE * 100
  };
}

/**
 * Calculate totals for an invoice
 * 
 * @param {array} lineItems - Array of line item objects
 * @returns {object} Object with invoice totals
 */
function calculateInvoiceTotals(lineItems) {
  if (!Array.isArray(lineItems) || lineItems.length === 0) {
    return {
      totalBeforeVAT: 0,
      totalSubtotal: 0,
      totalVAT: 0,
      totalAfterVAT: 0,
      lineCount: 0
    };
  }

  let totalSubtotal = 0;
  let totalBaseAmount = 0;
  let totalVAT = 0;

  lineItems.forEach(item => {
    const itemTotal = parseFloat(item.total || item.subtotal || 0);
    const itemBase = itemTotal / (1 + VAT_RATE);
    const itemVAT = itemTotal - itemBase;

    totalSubtotal += itemTotal;
    totalBaseAmount += itemBase;
    totalVAT += itemVAT;
  });

  return {
    totalBeforeVAT: Math.round(totalBaseAmount * 100) / 100,
    totalSubtotal: Math.round(totalSubtotal * 100) / 100,
    totalVAT: Math.round(totalVAT * 100) / 100,
    totalAfterVAT: Math.round((totalBaseAmount + totalVAT) * 100) / 100,
    lineCount: lineItems.length,
    vatPercentage: VAT_RATE * 100
  };
}

/**
 * Calculate VAT from a total amount (reverse calculation)
 * Use when you have the total and need to calculate the VAT portion
 * 
 * @param {number} totalAmount - Total amount including VAT
 * @returns {object} Object with breakdown
 */
function calculateVATFromTotal(totalAmount) {
  const baseAmount = totalAmount / (1 + VAT_RATE);
  const vatAmount = totalAmount - baseAmount;

  return {
    totalAmount,
    baseAmount: Math.round(baseAmount * 100) / 100,
    vatAmount: Math.round(vatAmount * 100) / 100,
    vatPercentage: VAT_RATE * 100
  };
}

/**
 * Format currency with proper decimals
 * 
 * @param {number} amount - Amount to format
 * @returns {number} Formatted amount
 */
function formatCurrency(amount) {
  return Math.round(parseFloat(amount) * 100) / 100;
}

/**
 * Validate VAT calculation
 * Checks if VAT calculations are correct
 * 
 * @param {number} baseAmount - Base amount (before VAT)
 * @param {number} vatAmount - VAT amount
 * @param {number} totalAmount - Total amount
 * @returns {boolean} True if valid
 */
function validateVATCalculation(baseAmount, vatAmount, totalAmount) {
  const calculatedTotal = baseAmount + vatAmount;
  const tolerance = 0.01; // Allow 1 cent difference due to rounding

  return Math.abs(calculatedTotal - totalAmount) <= tolerance;
}

/**
 * Log VAT calculation for debugging
 * 
 * @param {object} calculation - Calculation result
 * @param {string} description - Description of what's being calculated
 */
function logVATCalculation(calculation, description = '') {
  logger.info(`VAT Calculation ${description}:`);
  logger.info(`  Subtotal/Total Amount: ${calculation.subtotal || calculation.totalAmount}`);
  logger.info(`  Base Amount (Taxable): ${calculation.baseAmount || calculation.totalBeforeVAT}`);
  logger.info(`  VAT (${(VAT_RATE * 100)}%): ${calculation.vatAmount || calculation.totalVAT}`);
  logger.info(`  Total: ${calculation.total || calculation.totalAfterVAT}`);
}

module.exports = {
  VAT_RATE,
  calculateLineVAT,
  calculateInvoiceTotals,
  calculateVATFromTotal,
  formatCurrency,
  validateVATCalculation,
  logVATCalculation
};