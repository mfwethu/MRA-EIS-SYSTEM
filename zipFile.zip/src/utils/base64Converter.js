const base64Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/**
 * Convert Base10 number to Base64 string
 * @param {number} number
 * @returns {string}
 */
function toBase64(number) {
  if (number === 0) {
    return 'A'; // 'A' represents 0 in custom Base64
  }

  let result = '';
  while (number > 0) {
    const remainder = number % 64;
    result = base64Chars[remainder] + result;
    number = Math.floor(number / 64);
  }

  return result;
}

/**
 * Convert Base64 string back to Base10 number
 * @param {string} base64String
 * @returns {number}
 */
function fromBase64(base64String) {
  let result = 0;
  for (let i = 0; i < base64String.length; i++) {
    const index = base64Chars.indexOf(base64String[i]);
    if (index === -1) throw new Error(`Invalid Base64 character: ${base64String[i]}`);
    result = result * 64 + index;
  }
  return result;
}

module.exports = {
  toBase64,
  fromBase64
};