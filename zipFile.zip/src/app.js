const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
require('dotenv').config();
const logger = require('./utils/logger');

// Middleware imports
const { requestLogger } = require('./middlewares/requestLogger');
const { rateLimitAPI, rateLimitAuth } = require('./middlewares/rateLimiter');
const { errorHandler, notFound } = require('./middlewares/errorHandler');

// Route imports
const terminalRoutes = require('./routes/terminal');
const invoiceRoutes = require('./routes/invoices');
const inventoryRoutes = require('./routes/inventory');
const reportsRoutes = require('./routes/reports');
const inventoryFormRoutes = require('./routes/inventoryForm');
const utilsRoutes = require('./routes/utils');

// Create Express app
const app = express();

// =====================================================
// Security Middleware
// =====================================================
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// =====================================================
// Body Parser
// =====================================================
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// =====================================================
// Request Logging
// =====================================================
app.use(requestLogger);

// =====================================================
// Rate Limiting
// =====================================================
app.use(rateLimitAPI);

// =====================================================
// Static Files
// =====================================================
app.use(express.static('public'));

// =====================================================
// Health Check
// =====================================================
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// =====================================================
// Dashboard Route
// =====================================================
app.get('/', (req, res) => {
  res.sendFile(require('path').join(__dirname, '../public/html/dashboard.html'));
});

// =====================================================
// Terminal Activation Page
// =====================================================
app.get('/activate-terminal', (req, res) => {
  res.sendFile(require('path').join(__dirname, '../public/html/terminal-activation.html'));
});

// =====================================================
// Form Routes
// =====================================================
app.use('/inventory-form', inventoryFormRoutes);

// =====================================================
// API Routes
// =====================================================
app.use('/api/terminal', rateLimitAuth, terminalRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/utils', utilsRoutes);

// =====================================================
// 404 Handler
// =====================================================
app.use(notFound);

// =====================================================
// Error Handler (must be last)
// =====================================================
app.use(errorHandler);

module.exports = app;