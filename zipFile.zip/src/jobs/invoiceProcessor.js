const logger = require('../utils/logger');
const invoiceSubmissionService = require('../services/invoiceSubmissionService');
const inventorySubmissionService = require('../services/inventorySubmissionService');

let processingInterval = null;

/**
 * Start the invoice and inventory processor job
 * Runs every 5 minutes
 */
function startInvoiceProcessor() {
  logger.info('Starting invoice and inventory processor job...');

  // Run immediately on startup
  processData();

  // Then run every 5 minutes
  processingInterval = setInterval(() => {
    processData();
  }, 5 * 60 * 1000);

  logger.info('Processor job started - runs every 5 minutes');
}

/**
 * Stop the processor job
 */
function stopInvoiceProcessor() {
  if (processingInterval) {
    clearInterval(processingInterval);
    processingInterval = null;
    logger.info('Processor job stopped');
  }
}

/**
 * Process invoices and inventory
 */
async function processData() {
  try {
    logger.info('Running data processor job...');

    // Process invoices
    const invoiceResult = await invoiceSubmissionService.processPendingInvoices();
    if (invoiceResult.processed > 0) {
      logger.info(`Invoices: ${invoiceResult.successful} successful, ${invoiceResult.failed} failed`);
    }

    // Process inventory
    const inventoryResult = await inventorySubmissionService.processPendingInventory();
    if (inventoryResult.processed > 0) {
      logger.info(`Inventory: ${inventoryResult.successful} successful, ${inventoryResult.failed} failed`);
    }
  } catch (err) {
    logger.error('Error in processor job:', err);
  }
}

module.exports = {
  startInvoiceProcessor,
  stopInvoiceProcessor
};