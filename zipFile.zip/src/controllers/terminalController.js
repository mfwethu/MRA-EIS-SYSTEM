const logger = require('../utils/logger');
const mraTerminalService = require('../services/mraTerminalService');
const { getTerminalCreds, isTerminalActivated } = require('../utils/terminalState');

/**
 * Activate terminal
 */
exports.activateTerminal = async (req, res) => {
  try {
    const { activationCode, osName, osVersion, osBuild, macAddress } = req.body;

    if (!activationCode) {
      return res.status(400).json({
        success: false,
        message: 'Activation code is required'
      });
    }

    const environment = {
      platform: {
        osName: osName || 'Windows 11',
        osVersion: osVersion || 'Current Version',
        osBuild: osBuild || '11.901.2',
        macAddress: macAddress || '00-00-00-00-00-00'
      },
      pos: {
        productID: `MRA-desktop/${require('crypto').randomUUID()}`,
        productVersion: '1.0.0'
      }
    };

    const terminalData = await mraTerminalService.activateTerminal(activationCode, environment);

    logger.info('Terminal activated successfully');

    res.json({
      success: true,
      message: 'Terminal activated successfully',
      data: terminalData
    });
  } catch (err) {
    logger.error('Terminal activation error:', err);
    res.status(400).json({
      success: false,
      message: err.message || 'Failed to activate terminal'
    });
  }
};

/**
 * Get terminal status
 */
exports.getTerminalStatus = (req, res) => {
  try {
    const status = mraTerminalService.getTerminalStatus();

    res.json({
      success: true,
      data: status
    });
  } catch (err) {
    logger.error('Error getting terminal status:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

/**
 * Get terminal details
 */
exports.getTerminalDetails = (req, res) => {
  try {
    if (!isTerminalActivated()) {
      return res.status(400).json({
        success: false,
        message: 'Terminal not activated'
      });
    }

    const creds = getTerminalCreds();

    res.json({
      success: true,
      data: {
        terminalId: creds.terminalId,
        taxpayerId: creds.taxpayerId,
        terminalPosition: creds.terminalPosition,
        activationDate: creds.activationDate,
        configuration: creds.configuration
      }
    });
  } catch (err) {
    logger.error('Error getting terminal details:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

/**
 * Reset terminal
 */
exports.resetTerminal = (req, res) => {
  try {
    const { confirmReset } = req.body;

    if (confirmReset !== true) {
      return res.status(400).json({
        success: false,
        message: 'Reset not confirmed'
      });
    }

    require('../utils/terminalState').clearTerminalCreds();
    logger.warn('Terminal credentials reset');

    res.json({
      success: true,
      message: 'Terminal reset successfully'
    });
  } catch (err) {
    logger.error('Error resetting terminal:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};