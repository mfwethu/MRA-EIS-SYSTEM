const logger = require('../utils/logger');
const invoiceModel = require('../models/invoiceModel');
const mraInvoiceService = require('../services/mraInvoiceService');

/**
 * Submit invoice to MRA
 */
exports.submitInvoice = async (req, res) => {
  try {
    const invoiceData = req.body;

    if (!invoiceData.invoiceHeader || !invoiceData.invoiceLineItems) {
      return res.status(400).json({
        success: false,
        message: 'Invalid invoice data'
      });
    }

    const result = await mraInvoiceService.submitInvoice(invoiceData, 1);

    logger.info(`Invoice submitted successfully: ${result.invoiceNumber}`);

    res.json({
      success: true,
      message: 'Invoice submitted successfully',
      data: result
    });
  } catch (err) {
    logger.error('Invoice submission error:', err);
    res.status(400).json({
      success: false,
      message: err.message || 'Failed to submit invoice'
    });
  }
};

/**
 * Save invoice without submitting
 */
exports.saveInvoice = async (req, res) => {
  try {
    const invoiceData = req.body;

    if (!invoiceData.invoiceHeader || !invoiceData.invoiceLineItems) {
      return res.status(400).json({
        success: false,
        message: 'Invalid invoice data'
      });
    }

    const invoiceId = await invoiceModel.createInvoice(invoiceData);

    logger.info(`Invoice ${invoiceId} saved to database`);

    res.json({
      success: true,
      message: 'Invoice saved successfully',
      data: { invoiceId }
    });
  } catch (err) {
    logger.error('Invoice save error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Failed to save invoice'
    });
  }
};

/**
 * Get pending invoices (not yet submitted to MRA)
 */
exports.getPendingInvoices = async (req, res) => {
  try {
    const invoices = await invoiceModel.getPendingInvoices();

    res.json({
      success: true,
      data: invoices || [],
      count: invoices ? invoices.length : 0
    });
  } catch (err) {
    logger.error('Error fetching pending invoices:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch invoices',
      data: []
    });
  }
};

/**
 * Get invoice by ID
 */
exports.getInvoiceById = async (req, res) => {
  try {
    const { id } = req.params;

    const invoice = await invoiceModel.getInvoiceById(id);

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    res.json({
      success: true,
      data: invoice
    });
  } catch (err) {
    logger.error('Error fetching invoice:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch invoice'
    });
  }
};

/**
 * Delete invoice
 */
exports.deleteInvoice = async (req, res) => {
  try {
    const { id } = req.params;

    await invoiceModel.deleteInvoice(id);

    logger.info(`Invoice ${id} deleted`);

    res.json({
      success: true,
      message: 'Invoice deleted successfully'
    });
  } catch (err) {
    logger.error('Error deleting invoice:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to delete invoice'
    });
  }
};

/**
 * Get processed invoices (submitted to MRA)
 */
exports.getProcessedInvoices = async (req, res) => {
  try {
    const invoices = await invoiceModel.getProcessedInvoices();

    res.json({
      success: true,
      data: invoices || [],
      count: invoices ? invoices.length : 0
    });
  } catch (err) {
    logger.error('Error fetching processed invoices:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch invoices',
      data: []
    });
  }
};