const logger = require('../utils/logger');
const { executeQuery } = require('../config/database');

/**
 * Get invoice report
 */
exports.getInvoiceReport = async (req, res) => {
  try {
    const { status = 'all', startDate, endDate } = req.query;

    let query = '';

    if (status === 'pending') {
      query = `
        SELECT 'PENDING' as Status, InvoiceId, InvoiceNumber, InvoiceDateTime, 
               SellerTIN, BuyerTIN, PaymentMethod, NULL as MRAResponse, CreatedAt
        FROM InvoiceHeader
      `;
    } else if (status === 'processed') {
      query = `
        SELECT 'PROCESSED' as Status, ProcessedInvoiceId as InvoiceId, InvoiceNumber, InvoiceDateTime,
               SellerTIN, BuyerTIN, PaymentMethod, MRAResponse, SubmittedAt as CreatedAt
        FROM ProcessedInvoices
      `;
    } else {
      query = `
        SELECT 'PENDING' as Status, InvoiceId, InvoiceNumber, InvoiceDateTime,
               SellerTIN, BuyerTIN, PaymentMethod, NULL as MRAResponse, CreatedAt
        FROM InvoiceHeader
        UNION ALL
        SELECT 'PROCESSED' as Status, ProcessedInvoiceId as InvoiceId, InvoiceNumber, InvoiceDateTime,
               SellerTIN, BuyerTIN, PaymentMethod, MRAResponse, SubmittedAt as CreatedAt
        FROM ProcessedInvoices
      `;
    }

    // Add date filters if provided
    if (startDate || endDate) {
      const whereClause = [];
      if (startDate) whereClause.push(`CreatedAt >= '${startDate}'`);
      if (endDate) whereClause.push(`CreatedAt <= '${endDate}'`);
      query += ` WHERE ${whereClause.join(' AND ')}`;
    }

    query += ' ORDER BY CreatedAt DESC';

    const result = await executeQuery(query);

    res.json({
      success: true,
      data: result,
      count: result.length
    });
  } catch (err) {
    logger.error('Error generating invoice report:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to generate report'
    });
  }
};

/**
 * Get inventory report
 */
exports.getInventoryReport = async (req, res) => {
  try {
    const { status = 'all', startDate, endDate } = req.query;

    let query = '';

    if (status === 'pending') {
      query = `
        SELECT 'PENDING' as Status, InventoryId, BarCode, ProductName, QuantityInStock,
               UnitPrice, UploadedAt as SubmittedAt, NULL as MRAResponse
        FROM InventoryUpload
      `;
    } else if (status === 'processed') {
      query = `
        SELECT 'PROCESSED' as Status, ProcessedInventoryId as InventoryId, BarCode, ProductName, QuantityInStock,
               UnitPrice, SubmittedAt, MRAResponse
        FROM ProcessedInventory
      `;
    } else {
      query = `
        SELECT 'PENDING' as Status, InventoryId, BarCode, ProductName, QuantityInStock,
               UnitPrice, UploadedAt as SubmittedAt, NULL as MRAResponse
        FROM InventoryUpload
        UNION ALL
        SELECT 'PROCESSED' as Status, ProcessedInventoryId as InventoryId, BarCode, ProductName, QuantityInStock,
               UnitPrice, SubmittedAt, MRAResponse
        FROM ProcessedInventory
      `;
    }

    // Add date filters if provided
    if (startDate || endDate) {
      const whereClause = [];
      if (startDate) whereClause.push(`SubmittedAt >= '${startDate}'`);
      if (endDate) whereClause.push(`SubmittedAt <= '${endDate}'`);
      query += ` WHERE ${whereClause.join(' AND ')}`;
    }

    query += ' ORDER BY SubmittedAt DESC';

    const result = await executeQuery(query);

    res.json({
      success: true,
      data: result,
      count: result.length
    });
  } catch (err) {
    logger.error('Error generating inventory report:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to generate report'
    });
  }
};

/**
 * Get summary statistics
 */
exports.getSummary = async (req, res) => {
  try {
    const pendingInvoices = await executeQuery(`SELECT COUNT(*) as count FROM InvoiceHeader`);
    const processedInvoices = await executeQuery(`SELECT COUNT(*) as count FROM ProcessedInvoices`);
    const pendingInventory = await executeQuery(`SELECT COUNT(*) as count FROM InventoryUpload`);
    const processedInventory = await executeQuery(`SELECT COUNT(*) as count FROM ProcessedInventory`);

    const totalInvoiceAmount = await executeQuery(
      `SELECT ISNULL(SUM(InvoiceTotal), 0) as total FROM InvoiceSummary`
    );

    const totalInventoryValue = await executeQuery(
      `SELECT ISNULL(SUM(UnitPrice * QuantityInStock), 0) as total FROM ProcessedInventory`
    );

    res.json({
      success: true,
      data: {
        invoices: {
          pending: pendingInvoices[0]?.count || 0,
          processed: processedInvoices[0]?.count || 0,
          totalAmount: totalInvoiceAmount[0]?.total || 0
        },
        inventory: {
          pending: pendingInventory[0]?.count || 0,
          processed: processedInventory[0]?.count || 0,
          totalValue: totalInventoryValue[0]?.total || 0
        }
      }
    });
  } catch (err) {
    logger.error('Error generating summary:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to generate summary'
    });
  }
};