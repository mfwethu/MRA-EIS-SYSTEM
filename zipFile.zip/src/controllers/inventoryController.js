const logger = require('../utils/logger');
const inventoryModel = require('../models/inventoryModel');
const mraInventoryService = require('../services/mraInventoryService');

/**
 * Upload inventory to MRA
 */
exports.uploadInventory = async (req, res) => {
  try {
    const { products, isLastBatch } = req.body;

    if (!products || !Array.isArray(products) || products.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Products array is required'
      });
    }

    const result = await mraInventoryService.uploadInitialInventory(products, isLastBatch);

    res.json({
      success: true,
      message: 'Inventory uploaded successfully',
      data: result
    });
  } catch (err) {
    logger.error('Inventory upload error:', err);
    res.status(400).json({
      success: false,
      message: err.message || 'Failed to upload inventory'
    });
  }
};

/**
 * Save inventory without submitting
 */
exports.saveInventory = async (req, res) => {
  try {
    const { products } = req.body;

    if (!products || !Array.isArray(products) || products.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Products array is required'
      });
    }

    const inventoryIds = [];
    for (const product of products) {
      const inventoryId = await inventoryModel.createInventory('0', product);
      inventoryIds.push(inventoryId);
    }

    logger.info(`${products.length} inventory items saved`);

    res.json({
      success: true,
      message: `${products.length} items saved successfully`,
      data: { inventoryIds }
    });
  } catch (err) {
    logger.error('Inventory save error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Failed to save inventory'
    });
  }
};

/**
 * Get pending inventory
 */
exports.getPendingInventory = async (req, res) => {
  try {
    const inventory = await inventoryModel.getPendingInventory();

    res.json({
      success: true,
      data: inventory || [],
      count: inventory ? inventory.length : 0
    });
  } catch (err) {
    logger.error('Error fetching pending inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inventory',
      data: []
    });
  }
};

/**
 * Get processed inventory
 */
exports.getProcessedInventory = async (req, res) => {
  try {
    const inventory = await inventoryModel.getProcessedInventory();

    res.json({
      success: true,
      data: inventory || [],
      count: inventory ? inventory.length : 0
    });
  } catch (err) {
    logger.error('Error fetching processed inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inventory',
      data: []
    });
  }
};

/**
 * Get inventory by ID
 */
exports.getInventoryById = async (req, res) => {
  try {
    const { id } = req.params;

    const inventory = await inventoryModel.getInventoryById(id);

    if (!inventory) {
      return res.status(404).json({
        success: false,
        message: 'Inventory not found'
      });
    }

    res.json({
      success: true,
      data: inventory
    });
  } catch (err) {
    logger.error('Error fetching inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inventory'
    });
  }
};

/**
 * Delete inventory item
 */
exports.deleteInventory = async (req, res) => {
  try {
    const { id } = req.params;

    await inventoryModel.deleteInventory(id);

    logger.info(`Inventory item ${id} deleted`);

    res.json({
      success: true,
      message: 'Inventory deleted successfully'
    });
  } catch (err) {
    logger.error('Error deleting inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to delete inventory'
    });
  }
};

/**
 * Check for duplicate barcode
 */
exports.checkBarcode = async (req, res) => {
  try {
    const { barCode } = req.query;

    if (!barCode) {
      return res.status(400).json({
        success: false,
        message: 'Barcode is required'
      });
    }

    const inventory = await inventoryModel.getInventoryByBarcode(barCode);

    res.json({
      success: true,
      exists: !!inventory
    });
  } catch (err) {
    logger.error('Error checking barcode:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to check barcode'
    });
  }
};