const axios = require('axios');
const logger = require('../utils/logger');

const mraClient = axios.create({
  baseURL: process.env.MRA_API_BASE_URL,
  timeout: parseInt(process.env.MRA_API_TIMEOUT || 30000),
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
mraClient.interceptors.request.use(
  (config) => {
    logger.info(`📤 MRA API Request: ${config.method.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    logger.error('Request error:', error.message);
    return Promise.reject(error);
  }
);

// Response interceptor
mraClient.interceptors.response.use(
  (response) => {
    logger.info(`📥 MRA API Response: ${response.status}`);
    return response;
  },
  (error) => {
    const message = error.response?.data?.message || error.message;
    logger.error('MRA API Error:', message);
    return Promise.reject(error);
  }
);

module.exports = mraClient;