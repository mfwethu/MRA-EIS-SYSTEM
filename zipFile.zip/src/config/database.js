const sql = require('mssql');
const logger = require('../utils/logger');

// Log the environment variables being used
logger.info('Database Configuration:');
logger.info(`  Server: ${process.env.DB_SERVER || 'localhost'}`);
logger.info(`  Port: ${process.env.DB_PORT || 1433}`);
logger.info(`  User: ${process.env.DB_USER || 'root'}`);
logger.info(`  Database: ${process.env.DB_NAME || 'MRA_InvoiceDB'}`);

const config = {
  server: process.env.DB_SERVER || 'localhost',
  port: parseInt(process.env.DB_PORT || '1433'),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'root',
  database: process.env.DB_NAME || 'MRA_InvoiceDB',
  authentication: {
    type: 'default'
  },
  options: {
    encrypt: false,
    trustServerCertificate: true,
    enableKeepAlive: true,
    keepAliveInitialDelayMs: 30000,
    connectTimeout: 30000,
    requestTimeout: 30000
  },
  pool: {
    min: parseInt(process.env.DB_POOL_MIN || 2),
    max: parseInt(process.env.DB_POOL_MAX || 20),
    idleTimeoutMillis: 30000
  }
};

let pool = null;

async function getPool() {
  if (!pool) {
    try {
      logger.info('Attempting to connect to database...');
      logger.info(`  Server: ${config.server}:${config.port}`);
      logger.info(`  Database: ${config.database}`);
      logger.info(`  User: ${config.user}`);
      
      pool = new sql.ConnectionPool(config);
      
      pool.on('error', err => {
        logger.error('Unexpected error on idle client in pool:', err.message);
        pool = null;
      });
      
      await pool.connect();
      logger.info('✅ Database connected successfully');
      
      return pool;
    } catch (err) {
      logger.error('❌ Database connection failed:', err.message);
      logger.error('Error details:', err);
      pool = null;
      throw err;
    }
  }
  return pool;
}

async function executeQuery(query, params = []) {
  let request = null;
  try {
    const currentPool = await getPool();
    request = currentPool.request();
    
    if (params && Array.isArray(params)) {
      params.forEach((param) => {
        if (param && param.name && param.type !== undefined) {
          request.input(param.name, param.type, param.value);
        }
      });
    }
    
    const result = await request.query(query);
    return result.recordset || result.recordsets[0] || result;
  } catch (err) {
    logger.error('Query execution error:', err.message);
    // Attempt to reconnect on failure
    if (pool) {
      try {
        await pool.close();
      } catch (closeErr) {
        logger.error('Error closing pool:', closeErr.message);
      }
      pool = null;
    }
    throw err;
  }
}

async function closePool() {
  if (pool) {
    try {
      await pool.close();
      pool = null;
      logger.info('Database pool closed');
    } catch (err) {
      logger.error('Error closing pool:', err.message);
    }
  }
}

module.exports = {
  getPool,
  executeQuery,
  closePool,
  sql
};