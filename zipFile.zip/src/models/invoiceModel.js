const { executeQuery, sql } = require('../config/database');
const logger = require('../utils/logger');

/**
 * Create invoice record in database
 */
async function createInvoice(invoiceData) {
  try {
    const { invoiceHeader, invoiceLineItems, invoiceTaxBreakdown, invoiceSummary } = invoiceData;

    // Insert invoice header
    const headerResult = await executeQuery(
      `INSERT INTO InvoiceHeader 
       (InvoiceNumber, InvoiceDateTime, SellerTIN, BuyerTIN, BuyerName, BuyerAuthorizationCode,
        SiteId, GlobalConfigVersion, TaxpayerConfigVersion, TerminalConfigVersion, 
        IsReliefSupply, Vat5CertificateId, Vat5ProjectNumber, Vat5CertificateNumber, 
        Vat5Quantity, PaymentMethod)
       OUTPUT INSERTED.InvoiceId
       VALUES 
       (@invoiceNumber, @invoiceDateTime, @sellerTIN, @buyerTIN, @buyerName, @buyerAuthorizationCode,
        @siteId, @globalConfigVersion, @taxpayerConfigVersion, @terminalConfigVersion,
        @isReliefSupply, @vat5CertificateId, @vat5ProjectNumber, @vat5CertificateNumber,
        @vat5Quantity, @paymentMethod)`,
      [
        { name: 'invoiceNumber', type: sql.NVarChar, value: invoiceHeader.invoiceNumber },
        { name: 'invoiceDateTime', type: sql.DateTime2, value: new Date(invoiceHeader.invoiceDateTime) },
        { name: 'sellerTIN', type: sql.NVarChar, value: invoiceHeader.sellerTIN },
        { name: 'buyerTIN', type: sql.NVarChar, value: invoiceHeader.buyerTIN || '' },
        { name: 'buyerName', type: sql.NVarChar, value: invoiceHeader.buyerName || '' },
        { name: 'buyerAuthorizationCode', type: sql.NVarChar, value: invoiceHeader.buyerAuthorizationCode || '' },
        { name: 'siteId', type: sql.NVarChar, value: invoiceHeader.siteId },
        { name: 'globalConfigVersion', type: sql.Int, value: invoiceHeader.globalConfigVersion },
        { name: 'taxpayerConfigVersion', type: sql.Int, value: invoiceHeader.taxpayerConfigVersion },
        { name: 'terminalConfigVersion', type: sql.Int, value: invoiceHeader.terminalConfigVersion },
        { name: 'isReliefSupply', type: sql.Bit, value: invoiceHeader.isReliefSupply ? 1 : 0 },
        { name: 'vat5CertificateId', type: sql.Int, value: invoiceHeader.vat5CertificateDetails?.id || null },
        { name: 'vat5ProjectNumber', type: sql.NVarChar, value: invoiceHeader.vat5CertificateDetails?.projectNumber || '' },
        { name: 'vat5CertificateNumber', type: sql.NVarChar, value: invoiceHeader.vat5CertificateDetails?.certificateNumber || '' },
        { name: 'vat5Quantity', type: sql.Decimal, value: invoiceHeader.vat5CertificateDetails?.quantity || null },
        { name: 'paymentMethod', type: sql.NVarChar, value: invoiceHeader.paymentMethod }
      ]
    );

    const invoiceId = headerResult[0].InvoiceId;

    // Insert line items
    for (const item of invoiceLineItems) {
      await executeQuery(
        `INSERT INTO InvoiceLineItems 
         (InvoiceId, ProductCode, Description, UnitPrice, Quantity, Discount, Total, TotalVAT, TaxRateId, IsProduct)
         VALUES 
         (@invoiceId, @productCode, @description, @unitPrice, @quantity, @discount, @total, @totalVAT, @taxRateId, @isProduct)`,
        [
          { name: 'invoiceId', type: sql.Int, value: invoiceId },
          { name: 'productCode', type: sql.NVarChar, value: item.productCode },
          { name: 'description', type: sql.NVarChar, value: item.description },
          { name: 'unitPrice', type: sql.Decimal, value: item.unitPrice },
          { name: 'quantity', type: sql.Decimal, value: item.quantity },
          { name: 'discount', type: sql.Decimal, value: item.discount || 0 },
          { name: 'total', type: sql.Decimal, value: item.total },
          { name: 'totalVAT', type: sql.Decimal, value: item.totalVAT },
          { name: 'taxRateId', type: sql.NVarChar, value: item.taxRateId },
          { name: 'isProduct', type: sql.Bit, value: item.isProduct ? 1 : 0 }
        ]
      );
    }

    // Insert tax breakdown
    for (const tax of invoiceTaxBreakdown) {
      await executeQuery(
        `INSERT INTO InvoiceTaxBreakdown (InvoiceId, RateId, TaxableAmount, TaxAmount)
         VALUES (@invoiceId, @rateId, @taxableAmount, @taxAmount)`,
        [
          { name: 'invoiceId', type: sql.Int, value: invoiceId },
          { name: 'rateId', type: sql.NVarChar, value: tax.rateId },
          { name: 'taxableAmount', type: sql.Decimal, value: tax.taxableAmount },
          { name: 'taxAmount', type: sql.Decimal, value: tax.taxAmount }
        ]
      );
    }

    // Insert summary
    await executeQuery(
      `INSERT INTO InvoiceSummary (InvoiceId, TotalVAT, OfflineSignature, InvoiceTotal)
       VALUES (@invoiceId, @totalVAT, @offlineSignature, @invoiceTotal)`,
      [
        { name: 'invoiceId', type: sql.Int, value: invoiceId },
        { name: 'totalVAT', type: sql.Decimal, value: invoiceSummary.totalVAT },
        { name: 'offlineSignature', type: sql.NVarChar, value: invoiceSummary.offlineSignature || '' },
        { name: 'invoiceTotal', type: sql.Decimal, value: invoiceSummary.invoiceTotal }
      ]
    );

    logger.info(`Invoice ${invoiceId} created successfully`);
    return invoiceId;
  } catch (err) {
    logger.error('Error creating invoice:', err);
    throw err;
  }
}

/**
 * Get invoice by ID with all related data
 */
async function getInvoiceById(invoiceId) {
  try {
    const header = await executeQuery(
      `SELECT * FROM InvoiceHeader WHERE InvoiceId = @invoiceId`,
      [{ name: 'invoiceId', type: sql.Int, value: invoiceId }]
    );

    if (header.length === 0) {
      return null;
    }

    const lineItems = await executeQuery(
      `SELECT * FROM InvoiceLineItems WHERE InvoiceId = @invoiceId ORDER BY LineItemId`,
      [{ name: 'invoiceId', type: sql.Int, value: invoiceId }]
    );

    const taxBreakdown = await executeQuery(
      `SELECT * FROM InvoiceTaxBreakdown WHERE InvoiceId = @invoiceId`,
      [{ name: 'invoiceId', type: sql.Int, value: invoiceId }]
    );

    const summary = await executeQuery(
      `SELECT * FROM InvoiceSummary WHERE InvoiceId = @invoiceId`,
      [{ name: 'invoiceId', type: sql.Int, value: invoiceId }]
    );

    return {
      invoiceHeader: header[0],
      invoiceLineItems: lineItems,
      invoiceTaxBreakdown: taxBreakdown,
      invoiceSummary: summary[0]
    };
  } catch (err) {
    logger.error('Error fetching invoice:', err);
    throw err;
  }
}

/**
 * Get all pending invoices
 */
async function getPendingInvoices() {
  try {
    return await executeQuery(
      `SELECT ih.*, 
              (SELECT COUNT(*) FROM InvoiceLineItems WHERE InvoiceId = ih.InvoiceId) as LineItemCount,
              (SELECT SUM(InvoiceTotal) FROM InvoiceSummary WHERE InvoiceId = ih.InvoiceId) as InvoiceTotal
       FROM InvoiceHeader ih
       ORDER BY ih.InvoiceDateTime DESC`
    );
  } catch (err) {
    logger.error('Error fetching pending invoices:', err);
    throw err;
  }
}

/**
 * Get all processed invoices
 */
async function getProcessedInvoices() {
  try {
    return await executeQuery(
      `SELECT * FROM ProcessedInvoices ORDER BY SubmittedAt DESC`
    );
  } catch (err) {
    logger.error('Error fetching processed invoices:', err);
    throw err;
  }
}

/**
 * Delete invoice (before submission)
 */
async function deleteInvoice(invoiceId) {
  try {
    // Related records will be deleted due to CASCADE constraints
    await executeQuery(
      `DELETE FROM InvoiceHeader WHERE InvoiceId = @invoiceId`,
      [{ name: 'invoiceId', type: sql.Int, value: invoiceId }]
    );

    logger.info(`Invoice ${invoiceId} deleted`);
  } catch (err) {
    logger.error('Error deleting invoice:', err);
    throw err;
  }
}

/**
 * Move invoice to processed table
 */
async function moveToProcessed(invoiceId, mraResponse) {
  try {
    const invoice = await getInvoiceById(invoiceId);

    if (!invoice) {
      throw new Error('Invoice not found');
    }

    const header = invoice.invoiceHeader;

    await executeQuery(
      `INSERT INTO ProcessedInvoices 
       (InvoiceId, InvoiceNumber, InvoiceDateTime, SellerTIN, BuyerTIN, BuyerName, 
        BuyerAuthorizationCode, SiteId, GlobalConfigVersion, TaxpayerConfigVersion, 
        TerminalConfigVersion, IsReliefSupply, PaymentMethod, MRAResponse)
       VALUES 
       (@invoiceId, @invoiceNumber, @invoiceDateTime, @sellerTIN, @buyerTIN, @buyerName,
        @buyerAuthorizationCode, @siteId, @globalConfigVersion, @taxpayerConfigVersion,
        @terminalConfigVersion, @isReliefSupply, @paymentMethod, @mraResponse)`,
      [
        { name: 'invoiceId', type: sql.Int, value: invoiceId },
        { name: 'invoiceNumber', type: sql.NVarChar, value: header.InvoiceNumber },
        { name: 'invoiceDateTime', type: sql.DateTime2, value: header.InvoiceDateTime },
        { name: 'sellerTIN', type: sql.NVarChar, value: header.SellerTIN },
        { name: 'buyerTIN', type: sql.NVarChar, value: header.BuyerTIN },
        { name: 'buyerName', type: sql.NVarChar, value: header.BuyerName },
        { name: 'buyerAuthorizationCode', type: sql.NVarChar, value: header.BuyerAuthorizationCode },
        { name: 'siteId', type: sql.NVarChar, value: header.SiteId },
        { name: 'globalConfigVersion', type: sql.Int, value: header.GlobalConfigVersion },
        { name: 'taxpayerConfigVersion', type: sql.Int, value: header.TaxpayerConfigVersion },
        { name: 'terminalConfigVersion', type: sql.Int, value: header.TerminalConfigVersion },
        { name: 'isReliefSupply', type: sql.Bit, value: header.IsReliefSupply },
        { name: 'paymentMethod', type: sql.NVarChar, value: header.PaymentMethod },
        { name: 'mraResponse', type: sql.NVarChar, value: JSON.stringify(mraResponse) }
      ]
    );

    await deleteInvoice(invoiceId);
    logger.info(`Invoice ${invoiceId} moved to ProcessedInvoices`);
  } catch (err) {
    logger.error('Error moving invoice to processed:', err);
    throw err;
  }
}

module.exports = {
  createInvoice,
  getInvoiceById,
  getPendingInvoices,
  getProcessedInvoices,
  deleteInvoice,
  moveToProcessed
};