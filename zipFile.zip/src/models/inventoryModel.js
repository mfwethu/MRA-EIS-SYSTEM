const { executeQuery, sql } = require('../config/database');
const logger = require('../utils/logger');

/**
 * Create inventory record
 */
async function createInventory(tin, product) {
  try {
    const result = await executeQuery(
      `INSERT INTO InventoryUpload 
       (TIN, BarCode, ProductName, ProductDescription, QuantityInStock,
        UnitPrice, CostPrice, SellingPrice, ReorderLevel, OverQuantityStockLevel)
       OUTPUT INSERTED.InventoryId
       VALUES 
       (@tin, @barCode, @productName, @productDescription, @quantityInStock,
        @unitPrice, @costPrice, @sellingPrice, @reorderLevel, @overQuantityStockLevel)`,
      [
        { name: 'tin', type: sql.NVarChar, value: tin },
        { name: 'barCode', type: sql.NVarChar, value: product.barCode },
        { name: 'productName', type: sql.NVarChar, value: product.productName },
        { name: 'productDescription', type: sql.NVarChar, value: product.productDescription },
        { name: 'quantityInStock', type: sql.Decimal, value: product.quantityInStock },
        { name: 'unitPrice', type: sql.Decimal, value: product.unitPrice },
        { name: 'costPrice', type: sql.Decimal, value: product.costPrice },
        { name: 'sellingPrice', type: sql.Decimal, value: product.sellingPrice },
        { name: 'reorderLevel', type: sql.Decimal, value: product.reorderLevel },
        { name: 'overQuantityStockLevel', type: sql.Decimal, value: product.overQuantityStockLevel }
      ]
    );

    const inventoryId = result[0].InventoryId;
    logger.info(`Inventory item ${inventoryId} created`);
    return inventoryId;
  } catch (err) {
    logger.error('Error creating inventory:', err);
    throw err;
  }
}

/**
 * Get pending inventory items
 */
async function getPendingInventory() {
  try {
    return await executeQuery(
      `SELECT * FROM InventoryUpload ORDER BY UploadedAt DESC`
    );
  } catch (err) {
    logger.error('Error fetching pending inventory:', err);
    throw err;
  }
}

/**
 * Get inventory by ID
 */
async function getInventoryById(inventoryId) {
  try {
    const result = await executeQuery(
      `SELECT * FROM InventoryUpload WHERE InventoryId = @inventoryId`,
      [{ name: 'inventoryId', type: sql.Int, value: inventoryId }]
    );

    return result[0] || null;
  } catch (err) {
    logger.error('Error fetching inventory:', err);
    throw err;
  }
}

/**
 * Get processed inventory
 */
async function getProcessedInventory() {
  try {
    return await executeQuery(
      `SELECT * FROM ProcessedInventory ORDER BY SubmittedAt DESC`
    );
  } catch (err) {
    logger.error('Error fetching processed inventory:', err);
    throw err;
  }
}

/**
 * Delete inventory item
 */
async function deleteInventory(inventoryId) {
  try {
    await executeQuery(
      `DELETE FROM InventoryUpload WHERE InventoryId = @inventoryId`,
      [{ name: 'inventoryId', type: sql.Int, value: inventoryId }]
    );

    logger.info(`Inventory item ${inventoryId} deleted`);
  } catch (err) {
    logger.error('Error deleting inventory:', err);
    throw err;
  }
}

/**
 * Get inventory by barcode
 */
async function getInventoryByBarcode(barCode) {
  try {
    const result = await executeQuery(
      `SELECT * FROM InventoryUpload WHERE BarCode = @barCode`,
      [{ name: 'barCode', type: sql.NVarChar, value: barCode }]
    );

    return result[0] || null;
  } catch (err) {
    logger.error('Error fetching inventory by barcode:', err);
    throw err;
  }
}

/**
 * Move inventory to processed table
 */
async function moveToProcessed(inventoryIds, mraResponse) {
  try {
    for (const inventoryId of inventoryIds) {
      const item = await getInventoryById(inventoryId);

      if (!item) {
        logger.warn(`Inventory item ${inventoryId} not found`);
        continue;
      }

      await executeQuery(
        `INSERT INTO ProcessedInventory 
         (InventoryId, TIN, BarCode, ProductName, ProductDescription, QuantityInStock,
          UnitPrice, CostPrice, SellingPrice, ReorderLevel, OverQuantityStockLevel, MRAResponse)
         VALUES 
         (@inventoryId, @tin, @barCode, @productName, @productDescription, @quantityInStock,
          @unitPrice, @costPrice, @sellingPrice, @reorderLevel, @overQuantityStockLevel, @mraResponse)`,
        [
          { name: 'inventoryId', type: sql.Int, value: inventoryId },
          { name: 'tin', type: sql.NVarChar, value: item.TIN },
          { name: 'barCode', type: sql.NVarChar, value: item.BarCode },
          { name: 'productName', type: sql.NVarChar, value: item.ProductName },
          { name: 'productDescription', type: sql.NVarChar, value: item.ProductDescription },
          { name: 'quantityInStock', type: sql.Decimal, value: item.QuantityInStock },
          { name: 'unitPrice', type: sql.Decimal, value: item.UnitPrice },
          { name: 'costPrice', type: sql.Decimal, value: item.CostPrice },
          { name: 'sellingPrice', type: sql.Decimal, value: item.SellingPrice },
          { name: 'reorderLevel', type: sql.Decimal, value: item.ReorderLevel },
          { name: 'overQuantityStockLevel', type: sql.Decimal, value: item.OverQuantityStockLevel },
          { name: 'mraResponse', type: sql.NVarChar, value: JSON.stringify(mraResponse) }
        ]
      );

      await deleteInventory(inventoryId);
    }

    logger.info(`Moved ${inventoryIds.length} items to ProcessedInventory`);
  } catch (err) {
    logger.error('Error moving inventory to processed:', err);
    throw err;
  }
}

module.exports = {
  createInventory,
  getPendingInventory,
  getInventoryById,
  getProcessedInventory,
  deleteInventory,
  getInventoryByBarcode,
  moveToProcessed
};