const express = require('express');
const logger = require('../utils/logger');
const { VAT_RATE, calculateLineVAT, calculateInvoiceTotals, calculateVATFromTotal, validateVATCalculation } = require('../utils/vatCalculator');

const router = express.Router();

/**
 * GET /api/utils/vat-info
 * Get VAT information and rates
 */
router.get('/vat-info', (req, res) => {
  res.json({
    success: true,
    data: {
      vatRate: VAT_RATE,
      vatPercentage: VAT_RATE * 100,
      description: 'VAT is charged at 17.5% on all standard-rated supplies',
      formula: {
        totalAmount: 'Unit Price × Quantity - Discount',
        baseAmount: 'Total Amount ÷ 1.175',
        vatAmount: 'Total Amount - Base Amount'
      },
      example: {
        unitPrice: 1000,
        quantity: 1,
        discount: 0,
        totalAmount: 1000,
        baseAmount: 851.06,
        vatAmount: 148.94
      }
    }
  });
});

/**
 * POST /api/utils/calculate-vat
 * Calculate VAT for given amounts
 */
router.post('/calculate-vat', (req, res) => {
  try {
    const { unitPrice, quantity, discount = 0, lineItems } = req.body;

    if (lineItems && Array.isArray(lineItems)) {
      // Calculate for multiple line items
      const result = calculateInvoiceTotals(lineItems);
      return res.json({
        success: true,
        data: result
      });
    }

    if (unitPrice && quantity !== undefined) {
      // Calculate for single line item
      const result = calculateLineVAT(unitPrice, quantity, discount);
      return res.json({
        success: true,
        data: result
      });
    }

    res.status(400).json({
      success: false,
      message: 'Please provide either unitPrice and quantity, or lineItems array'
    });
  } catch (err) {
    logger.error('Error calculating VAT:', err);
    res.status(500).json({
      success: false,
      message: err.message
    });
  }
});

/**
 * POST /api/utils/validate-vat
 * Validate VAT calculations
 */
router.post('/validate-vat', (req, res) => {
  try {
    const { baseAmount, vatAmount, totalAmount } = req.body;

    if (!baseAmount || !vatAmount || !totalAmount) {
      return res.status(400).json({
        success: false,
        message: 'Please provide baseAmount, vatAmount, and totalAmount'
      });
    }

    const isValid = validateVATCalculation(baseAmount, vatAmount, totalAmount);

    const calculatedTotal = baseAmount + vatAmount;
    const difference = Math.abs(calculatedTotal - totalAmount);

    res.json({
      success: true,
      data: {
        isValid,
        baseAmount: parseFloat(baseAmount),
        vatAmount: parseFloat(vatAmount),
        totalAmount: parseFloat(totalAmount),
        calculatedTotal: Math.round(calculatedTotal * 100) / 100,
        difference: Math.round(difference * 100) / 100,
        tolerance: 0.01,
        message: isValid ? 'VAT calculation is correct' : 'VAT calculation has discrepancies'
      }
    });
  } catch (err) {
    logger.error('Error validating VAT:', err);
    res.status(500).json({
      success: false,
      message: err.message
    });
  }
});

module.exports = router;