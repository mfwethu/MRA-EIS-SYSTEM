const express = require('express');
const logger = require('../utils/logger');
const invoiceController = require('../controllers/invoiceController');
const { executeQuery, sql } = require('../config/database');

const router = express.Router();

// Don't require terminal activation for read operations
router.get('/pending', invoiceController.getPendingInvoices);
router.get('/processed', invoiceController.getProcessedInvoices);
router.get('/:id', invoiceController.getInvoiceById);
router.post('/submit', invoiceController.submitInvoice);
router.post('/save', invoiceController.saveInvoice);
router.delete('/:id', invoiceController.deleteInvoice);

/**
 * GET /api/invoices/processing-history/:id
 * Get processing history for an invoice
 */
router.get('/processing-history/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const history = await executeQuery(
      `SELECT * FROM InvoiceProcessingHistory WHERE InvoiceId = @invoiceId ORDER BY ProcessedAt DESC`,
      [{ name: 'invoiceId', type: sql.Int, value: id }]
    );

    res.json({
      success: true,
      data: history
    });
  } catch (err) {
    logger.error('Error fetching processing history:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch processing history'
    });
  }
});

/**
 * GET /api/invoices/failed
 * Get all failed invoice submissions
 */
router.get('/failed', async (req, res) => {
  try {
    const failed = await executeQuery(
      `SELECT f.*, ih.InvoiceNumber, ih.InvoiceDateTime 
       FROM FailedInvoiceSubmissions f
       LEFT JOIN InvoiceHeader ih ON f.InvoiceId = ih.InvoiceId
       ORDER BY f.AttemptedAt DESC`
    );

    res.json({
      success: true,
      data: failed || [],
      count: failed ? failed.length : 0
    });
  } catch (err) {
    logger.error('Error fetching failed invoices:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch failed invoices',
      data: []
    });
  }
});

/**
 * POST /api/invoices/process-pending
 * Manually trigger processing of pending invoices
 */
router.post('/process-pending', async (req, res) => {
  try {
    const invoiceSubmissionService = require('../services/invoiceSubmissionService');
    const result = await invoiceSubmissionService.processPendingInvoices();

    res.json({
      success: true,
      message: `Processed ${result.processed} invoices`,
      data: result
    });
  } catch (err) {
    logger.error('Error processing invoices:', err);
    res.status(500).json({
      success: false,
      message: err.message
    });
  }
});

/**
 * GET /api/invoices/stats
 * Get invoice processing statistics
 */
router.get('/stats', async (req, res) => {
  try {
    const pending = await executeQuery('SELECT COUNT(*) as count FROM InvoiceHeader');
    const processed = await executeQuery('SELECT COUNT(*) as count FROM ProcessedInvoices');
    const failed = await executeQuery('SELECT COUNT(*) as count FROM FailedInvoiceSubmissions WHERE ResolvedAt IS NULL');
    
    const totalValue = await executeQuery('SELECT ISNULL(SUM(InvoiceTotal), 0) as total FROM InvoiceSummary');

    res.json({
      success: true,
      data: {
        pending: pending[0]?.count || 0,
        processed: processed[0]?.count || 0,
        failed: failed[0]?.count || 0,
        totalValue: totalValue[0]?.total || 0
      }
    });
  } catch (err) {
    logger.error('Error getting invoice stats:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to get statistics',
      data: { pending: 0, processed: 0, failed: 0, totalValue: 0 }
    });
  }
});

module.exports = router;