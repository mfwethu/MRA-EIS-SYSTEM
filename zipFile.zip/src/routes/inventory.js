const express = require('express');
const logger = require('../utils/logger');
const inventoryController = require('../controllers/inventoryController');
const { executeQuery, sql } = require('../config/database');

const router = express.Router();

// Don't require terminal activation for read operations
router.get('/pending', inventoryController.getPendingInventory);
router.get('/submitted', async (req, res) => {
  try {
    const inventory = await executeQuery(
      `SELECT * FROM SubmittedInventory ORDER BY SubmittedAt DESC`
    );

    res.json({
      success: true,
      data: inventory || [],
      count: inventory ? inventory.length : 0
    });
  } catch (err) {
    logger.error('Error fetching submitted inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inventory',
      data: []
    });
  }
});
router.get('/:id', inventoryController.getInventoryById);
router.post('/upload', inventoryController.uploadInventory);
router.post('/save', inventoryController.saveInventory);
router.delete('/:id', inventoryController.deleteInventory);
router.get('/check-barcode', inventoryController.checkBarcode);

/**
 * GET /api/inventory/failed
 * Get failed inventory submissions
 */
router.get('/failed', async (req, res) => {
  try {
    const failed = await executeQuery(
      `SELECT f.*, i.BarCode, i.ProductName
       FROM FailedInventorySubmissions f
       LEFT JOIN InventoryUpload i ON f.InventoryId = i.InventoryId
       ORDER BY f.AttemptedAt DESC`
    );

    res.json({
      success: true,
      data: failed || [],
      count: failed ? failed.length : 0
    });
  } catch (err) {
    logger.error('Error fetching failed inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch failed inventory',
      data: []
    });
  }
});

/**
 * POST /api/inventory/process-pending
 * Manually trigger processing of pending inventory
 */
router.post('/process-pending', async (req, res) => {
  try {
    const inventorySubmissionService = require('../services/inventorySubmissionService');
    const result = await inventorySubmissionService.processPendingInventory();

    res.json({
      success: true,
      message: `Processed ${result.processed} inventory items`,
      data: result
    });
  } catch (err) {
    logger.error('Error processing inventory:', err);
    res.status(500).json({
      success: false,
      message: err.message
    });
  }
});

/**
 * GET /api/inventory/stats
 * Get inventory statistics
 */
router.get('/stats', async (req, res) => {
  try {
    const pending = await executeQuery('SELECT COUNT(*) as count FROM InventoryUpload');
    const submitted = await executeQuery('SELECT COUNT(*) as count FROM SubmittedInventory');
    const failed = await executeQuery('SELECT COUNT(*) as count FROM FailedInventorySubmissions WHERE ResolvedAt IS NULL');
    
    const totalValue = await executeQuery(
      'SELECT ISNULL(SUM(UnitPrice * QuantityInStock), 0) as total FROM SubmittedInventory'
    );

    res.json({
      success: true,
      data: {
        pending: pending[0]?.count || 0,
        submitted: submitted[0]?.count || 0,
        failed: failed[0]?.count || 0,
        totalValue: totalValue[0]?.total || 0
      }
    });
  } catch (err) {
    logger.error('Error getting inventory stats:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to get statistics',
      data: { pending: 0, submitted: 0, failed: 0, totalValue: 0 }
    });
  }
});

module.exports = router;