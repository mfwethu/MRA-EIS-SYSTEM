const express = require('express');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * Serve inventory management form
 */
router.get('/', (req, res) => {
  try {
    logger.info('Inventory form accessed');
    res.sendFile(require('path').join(__dirname, '../../public/html/inventory-form.html'));
  } catch (err) {
    logger.error('Error serving inventory form:', err);
    res.status(500).json({
      success: false,
      message: 'Error loading inventory form'
    });
  }
});

module.exports = router;