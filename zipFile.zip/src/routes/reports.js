const express = require('express');
const logger = require('../utils/logger');
const reportController = require('../controllers/reportController');
const { executeQuery } = require('../config/database');

const router = express.Router();

router.get('/invoices', reportController.getInvoiceReport);
router.get('/inventory', reportController.getInventoryReport);
router.get('/summary', reportController.getSummary);

/**
 * GET /api/reports/failed-invoices
 * Get failed invoice submission report
 */
router.get('/failed-invoices', async (req, res) => {
  try {
    const failed = await executeQuery(
      `SELECT f.*, ih.InvoiceNumber, ih.InvoiceDateTime, ih.SellerTIN
       FROM FailedInvoiceSubmissions f
       LEFT JOIN InvoiceHeader ih ON f.InvoiceId = ih.InvoiceId
       ORDER BY f.AttemptedAt DESC`
    );

    res.json({
      success: true,
      data: failed || [],
      count: failed ? failed.length : 0
    });
  } catch (err) {
    logger.error('Error fetching failed invoices:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch failed invoices',
      data: []
    });
  }
});

/**
 * GET /api/reports/failed-inventory
 * Get failed inventory submission report
 */
router.get('/failed-inventory', async (req, res) => {
  try {
    const failed = await executeQuery(
      `SELECT f.*, i.BarCode, i.ProductName, i.QuantityInStock, i.UnitPrice
       FROM FailedInventorySubmissions f
       LEFT JOIN InventoryUpload i ON f.InventoryId = i.InventoryId
       ORDER BY f.AttemptedAt DESC`
    );

    res.json({
      success: true,
      data: failed || [],
      count: failed ? failed.length : 0
    });
  } catch (err) {
    logger.error('Error fetching failed inventory:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch failed inventory',
      data: []
    });
  }
});

/**
 * GET /api/reports/all-submissions
 * Get comprehensive submission report
 */
router.get('/all-submissions', async (req, res) => {
  try {
    const summary = await executeQuery(
      `SELECT 
        (SELECT COUNT(*) FROM InvoiceHeader) as pendingInvoices,
        (SELECT COUNT(*) FROM ProcessedInvoices) as submittedInvoices,
        (SELECT COUNT(*) FROM FailedInvoiceSubmissions WHERE ResolvedAt IS NULL) as failedInvoices,
        (SELECT COUNT(*) FROM InventoryUpload) as pendingInventory,
        (SELECT COUNT(*) FROM SubmittedInventory) as submittedInventory,
        (SELECT COUNT(*) FROM FailedInventorySubmissions WHERE ResolvedAt IS NULL) as failedInventory`
    );

    res.json({
      success: true,
      data: summary[0] || {}
    });
  } catch (err) {
    logger.error('Error getting submission report:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to get report'
    });
  }
});

module.exports = router;