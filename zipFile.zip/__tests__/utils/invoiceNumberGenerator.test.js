const { generateInvoiceNumber, toJulianDate } = require('../../src/utils/invoiceNumberGenerator');

describe('Invoice Number Generator', () => {
  describe('toJulianDate', () => {
    it('should convert date to Julian date', () => {
      const date = new Date('2026-01-01');
      const julianDate = toJulianDate(date);
      expect(typeof julianDate).toBe('number');
      expect(julianDate).toBeGreaterThan(0);
    });

    it('should return consistent Julian dates for same date', () => {
      const date = new Date('2026-06-15');
      expect(toJulianDate(date)).toBe(toJulianDate(date));
    });
  });

  describe('generateInvoiceNumber', () => {
    it('should generate invoice number with required parameters', () => {
      const params = {
        taxpayerId: 10713,
        terminalPosition: 1,
        transactionDate: new Date('2026-02-13'),
        transactionCount: 1
      };

      const invoiceNumber = generateInvoiceNumber(params);
      expect(invoiceNumber).toBeDefined();
      expect(typeof invoiceNumber).toBe('string');
      expect(invoiceNumber).toContain('-');
    });

    it('should throw error when missing parameters', () => {
      expect(() => generateInvoiceNumber({})).toThrow();
    });

    it('should generate different numbers for different counts', () => {
      const baseParams = {
        taxpayerId: 10713,
        terminalPosition: 1,
        transactionDate: new Date('2026-02-13')
      };

      const num1 = generateInvoiceNumber({ ...baseParams, transactionCount: 1 });
      const num2 = generateInvoiceNumber({ ...baseParams, transactionCount: 2 });

      expect(num1).not.toBe(num2);
    });
  });
});