const { toBase64, fromBase64 } = require('../../src/utils/base64Converter');

describe('Base64 Converter', () => {
  describe('toBase64', () => {
    it('should convert 0 to A', () => {
      expect(toBase64(0)).toBe('A');
    });

    it('should convert positive numbers to base64', () => {
      expect(toBase64(1)).toBe('B');
      expect(toBase64(63)).toBe('/');
      expect(toBase64(64)).toBe('BA');
    });

    it('should handle large numbers', () => {
      expect(toBase64(10000)).toBeDefined();
      expect(typeof toBase64(10000)).toBe('string');
    });
  });

  describe('fromBase64', () => {
    it('should convert A back to 0', () => {
      expect(fromBase64('A')).toBe(0);
    });

    it('should reverse toBase64 conversion', () => {
      const original = 12345;
      const encoded = toBase64(original);
      const decoded = fromBase64(encoded);
      expect(decoded).toBe(original);
    });

    it('should throw error for invalid characters', () => {
      expect(() => fromBase64('!')).toThrow();
    });
  });
});