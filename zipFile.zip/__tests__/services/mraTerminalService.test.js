const mraTerminalService = require('../../src/services/mraTerminalService');
const { getTerminalCreds } = require('../../src/utils/terminalState');

jest.mock('../../src/utils/terminalState');

describe('MRA Terminal Service', () => {
  describe('getTerminalStatus', () => {
    it('should return not activated when no credentials exist', () => {
      getTerminalCreds.mockReturnValue(null);
      const status = mraTerminalService.getTerminalStatus();
      expect(status.isActivated).toBe(false);
    });

    it('should return activated status with credentials', () => {
      const mockCreds = {
        terminalId: 'test-id',
        taxpayerId: 12345,
        activationDate: new Date().toISOString()
      };
      getTerminalCreds.mockReturnValue(mockCreds);
      const status = mraTerminalService.getTerminalStatus();
      expect(status.isActivated).toBe(true);
      expect(status.terminalId).toBe('test-id');
    });
  });

  describe('validateTerminalCredentials', () => {
    it('should return false when no credentials exist', () => {
      getTerminalCreds.mockReturnValue(null);
      expect(mraTerminalService.validateTerminalCredentials()).toBe(false);
    });

    it('should validate complete credentials', () => {
      const mockCreds = {
        terminalId: 'test-id',
        taxpayerId: 12345,
        jwtToken: 'test-token',
        secretKey: 'test-key',
        activationDate: new Date().toISOString()
      };
      getTerminalCreds.mockReturnValue(mockCreds);
      expect(mraTerminalService.validateTerminalCredentials()).toBe(true);
    });
  });
});