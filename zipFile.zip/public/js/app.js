// =====================================================
// MRA Invoice System - Frontend Application
// =====================================================

const API_BASE = '/api';
let terminalCreds = null;
let currentLineItemCount = 1;
let currentInventoryItemCount = 1;

// =====================================================
// Initialization
// =====================================================

document.addEventListener('DOMContentLoaded', function () {
  loadTerminalStatus();
  loadDashboardData();
  setupFormDefaults();
  setInterval(refreshDashboard, 30000); // Refresh every 30 seconds
});

function setupFormDefaults() {
  // Set current date/time
  const now = new Date();
  const isoDateTime = now.toISOString().slice(0, 16);
  document.getElementById('inv-date').value = isoDateTime;
}

// =====================================================
// Terminal Management
// =====================================================

function loadTerminalStatus() {
  fetch(`${API_BASE}/terminal/status`)
    .then((res) => res.json())
    .then((data) => {
      const statusCard = document.getElementById('terminal-status-card');
      const statusText = document.getElementById('terminal-status-text');
      const detailsText = document.getElementById('terminal-details');

      if (data.data.isActivated) {
        statusCard.classList.remove('inactive');
        statusCard.classList.add('active');
        statusText.textContent = 'Activated ✓';
        detailsText.innerHTML = `
          <strong>Terminal ID:</strong> ${data.data.terminalId}<br>
          <strong>Taxpayer ID:</strong> ${data.data.taxpayerId}<br>
          <strong>Activated:</strong> ${new Date(data.data.activationDate).toLocaleString()}
        `;
        loadTerminalDetails();
      } else {
        statusCard.classList.remove('active');
        statusCard.classList.add('inactive');
        statusText.textContent = 'Not Activated';
        detailsText.innerHTML = 'Please activate your terminal to begin operations.';
      }
    })
    .catch((err) => {
      console.error('Error loading terminal status:', err);
      document.getElementById('terminal-status-card').classList.add('inactive');
    });
}

function loadTerminalDetails() {
  fetch(`${API_BASE}/terminal/details`)
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        terminalCreds = data.data;
        const card = document.getElementById('terminal-info-card');
        const content = document.getElementById('terminal-details-content');

        let html = `
          <div class="row">
            <div class="col-md-6">
              <p><strong>Terminal ID:</strong> ${data.data.terminalId}</p>
              <p><strong>Taxpayer ID:</strong> ${data.data.taxpayerId}</p>
              <p><strong>Terminal Position:</strong> ${data.data.terminalPosition}</p>
            </div>
            <div class="col-md-6">
              <p><strong>Activation Date:</strong> ${new Date(data.data.activationDate).toLocaleString()}</p>
              <p><strong>Tax Office:</strong> ${data.data.configuration?.taxpayerConfiguration?.taxOffice?.name || 'N/A'}</p>
              <p><strong>TIN:</strong> ${data.data.configuration?.taxpayerConfiguration?.tin || 'N/A'}</p>
            </div>
          </div>
          <hr>
          <h6>Tax Rates:</h6>
          <ul class="list-unstyled">
            ${data.data.configuration?.globalConfiguration?.taxrates
              ?.map(
                (rate) =>
                  `<li><strong>${rate.name} (${rate.id}):</strong> ${rate.rate}%</li>`
              )
              .join('') || '<li>No tax rates configured</li>'}
          </ul>
        `;

        content.innerHTML = html;
        card.style.display = 'block';
      }
    })
    .catch((err) => console.error('Error loading terminal details:', err));
}

document.getElementById('terminal-activation-form')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const data = {
    activationCode: document.getElementById('activationCode').value,
    osName: document.getElementById('osName').value,
    osVersion: document.getElementById('osVersion').value,
    osBuild: document.getElementById('osBuild').value,
    macAddress: document.getElementById('macAddress').value
  };

  showLoading(true);

  fetch(`${API_BASE}/terminal/activate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
    .then((res) => res.json())
    .then((data) => {
      showLoading(false);
      if (data.success) {
        showAlert('✅ Terminal activated successfully!', 'success');
        loadTerminalStatus();
        loadTerminalDetails();
        this.reset();
      } else {
        showAlert('❌ ' + (data.message || 'Activation failed'), 'danger');
      }
    })
    .catch((err) => {
      showLoading(false);
      console.error('Error:', err);
      showAlert('Error activating terminal: ' + err.message, 'danger');
    });
});

// =====================================================
// Dashboard Functions
// =====================================================

function loadDashboardData() {
  loadPendingInvoicesCount();
  loadProcessedInvoicesCount();
  loadPendingInventoryCount();
}

function refreshDashboard() {
  loadDashboardData();
}

function loadPendingInvoicesCount() {
  fetch(`${API_BASE}/invoices/pending`)
    .then((res) => res.json())
    .then((data) => {
      document.getElementById('pending-invoices-count').textContent = data.data?.length || 0;
    })
    .catch(() => {});
}

function loadProcessedInvoicesCount() {
  fetch(`${API_BASE}/invoices/processed`)
    .then((res) => res.json())
    .then((data) => {
      document.getElementById('processed-invoices-count').textContent = data.count || 0;
    })
    .catch(() => {});
}

function loadPendingInventoryCount() {
  fetch(`${API_BASE}/inventory/pending`)
    .then((res) => res.json())
    .then((data) => {
      document.getElementById('pending-inventory-count').textContent = data.count || 0;
    })
    .catch(() => {});
}

// =====================================================
// Invoice Functions
// =====================================================

function addLineItem() {
  currentLineItemCount++;
  const container = document.getElementById('line-items-container');
  const html = `
    <div class="line-item card mb-2 p-3">
      <div class="row">
        <div class="col-md-3 mb-2">
          <input type="text" class="form-control form-control-sm" placeholder="Product Code" required>
        </div>
        <div class="col-md-4 mb-2">
          <input type="text" class="form-control form-control-sm" placeholder="Description" required>
        </div>
        <div class="col-md-2 mb-2">
          <input type="number" class="form-control form-control-sm" placeholder="Qty" min="1" step="0.01" required>
        </div>
        <div class="col-md-2 mb-2">
          <input type="number" class="form-control form-control-sm" placeholder="Price" min="0" step="0.01" required>
        </div>
        <div class="col-md-1 mb-2">
          <button type="button" class="btn btn-sm btn-danger" onclick="removeLineItem(this)">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  `;
  container.insertAdjacentHTML('beforeend', html);
}

function removeLineItem(btn) {
  btn.closest('.line-item').remove();
}

function submitInvoice() {
  if (!terminalCreds) {
    showAlert('❌ Terminal not activated', 'danger');
    return;
  }

  const form = document.getElementById('invoice-form');
  const lineItems = [];
  
  document.querySelectorAll('.line-item').forEach((item) => {
    const inputs = item.querySelectorAll('input');
    const qty = parseFloat(inputs[2].value);
    const price = parseFloat(inputs[3].value);
    const total = qty * price;
    
    lineItems.push({
      productCode: inputs[0].value,
      description: inputs[1].value,
      quantity: qty,
      unitPrice: price,
      total: total,
      totalVAT: total * 0.205, // 20.5% VAT
      taxRateId: 'A',
      isProduct: true,
      discount: 0
    });
  });

  if (lineItems.length === 0) {
    showAlert('❌ Please add at least one line item', 'warning');
    return;
  }

  const totalVAT = parseFloat(document.getElementById('total-vat').value) || 0;
  const invoiceTotal = parseFloat(document.getElementById('invoice-total').value) || 0;

  const invoiceData = {
    invoiceHeader: {
      invoiceNumber: document.getElementById('inv-number').value,
      invoiceDateTime: document.getElementById('inv-date').value,
      sellerTIN: terminalCreds?.taxpayerId?.toString() || '',
      buyerTIN: document.getElementById('buyer-tin').value || '',
      buyerName: document.getElementById('buyer-name').value || '',
      buyerAuthorizationCode: '',
      siteId: document.getElementById('site-id').value,
      globalConfigVersion: 1,
      taxpayerConfigVersion: 1,
      terminalConfigVersion: 1,
      isReliefSupply: false,
      vat5CertificateDetails: {
        id: 0,
        projectNumber: '',
        certificateNumber: '',
        quantity: 0
      },
      paymentMethod: document.getElementById('payment-method').value || 'CASH'
    },
    invoiceLineItems: lineItems,
    invoiceTaxBreakdown: [
      {
        rateId: 'A',
        taxableAmount: invoiceTotal - totalVAT,
        taxAmount: totalVAT
      }
    ],
    invoiceSummary: {
      taxBreakDown: [
        {
          rateId: 'A',
          taxableAmount: invoiceTotal - totalVAT,
          taxAmount: totalVAT
        }
      ],
      levyBreakDown: [],
      totalVAT: totalVAT,
      offlineSignature: '',
      invoiceTotal: invoiceTotal
    }
  };

  showLoading(true);

  fetch(`${API_BASE}/invoices/submit`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(invoiceData)
  })
    .then((res) => res.json())
    .then((data) => {
      showLoading(false);
      if (data.success) {
        showAlert('✅ Invoice submitted successfully!', 'success');
        bootstrap.Modal.getInstance(document.getElementById('invoiceFormModal')).hide();
        document.getElementById('invoice-form').reset();
        loadDashboardData();
        loadPendingInvoices();
      } else {
        showAlert('❌ ' + (data.message || 'Submission failed'), 'danger');
      }
    })
    .catch((err) => {
      showLoading(false);
      console.error('Error:', err);
      showAlert('Error submitting invoice: ' + err.message, 'danger');
    });
}

function loadPendingInvoices() {
  fetch(`${API_BASE}/invoices/pending`)
    .then((res) => res.json())
    .then((data) => {
      const tbody = document.getElementById('pending-invoices-list');
      if (data.data && data.data.length > 0) {
        tbody.innerHTML = data.data
          .map(
            (inv) => `
          <tr>
            <td><strong>${inv.InvoiceNumber}</strong></td>
            <td>${new Date(inv.InvoiceDateTime).toLocaleDateString()}</td>
            <td>${inv.SellerTIN}</td>
            <td>${inv.InvoiceTotal?.toFixed(2) || 'N/A'}</td>
            <td><span class="badge bg-secondary">${inv.PaymentMethod}</span></td>
            <td>
              <button class="btn btn-sm btn-danger" onclick="deleteInvoice(${inv.InvoiceId})">
                <i class="fas fa-trash"></i> Delete
              </button>
            </td>
          </tr>
        `
          )
          .join('');
      } else {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No pending invoices</td></tr>';
      }
    })
    .catch((err) => console.error('Error loading invoices:', err));
}

function loadSubmittedInvoices() {
  fetch(`${API_BASE}/invoices/processed`)
    .then((res) => res.json())
    .then((data) => {
      const tbody = document.getElementById('submitted-invoices-list');
      if (data.data && data.data.length > 0) {
        tbody.innerHTML = data.data
          .map(
            (inv) => `
          <tr>
            <td><strong>${inv.InvoiceNumber}</strong></td>
            <td>${new Date(inv.InvoiceDateTime).toLocaleDateString()}</td>
            <td>${inv.SellerTIN}</td>
            <td>${inv.InvoiceTotal?.toFixed(2) || 'N/A'}</td>
            <td>${new Date(inv.SubmittedAt).toLocaleString()}</td>
            <td><span class="badge bg-success">Submitted</span></td>
          </tr>
        `
          )
          .join('');
      } else {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No submitted invoices</td></tr>';
      }
    })
    .catch((err) => console.error('Error loading submitted invoices:', err));
}

function deleteInvoice(invoiceId) {
  if (!confirm('Are you sure you want to delete this invoice?')) return;

  showLoading(true);

  fetch(`${API_BASE}/invoices/${invoiceId}`, { method: 'DELETE' })
    .then((res) => res.json())
    .then((data) => {
      showLoading(false);
      if (data.success) {
        showAlert('✅ Invoice deleted', 'success');
        loadPendingInvoices();
        loadDashboardData();
      } else {
        showAlert('❌ Failed to delete invoice', 'danger');
      }
    })
    .catch((err) => {
      showLoading(false);
      showAlert('Error: ' + err.message, 'danger');
    });
}

// =====================================================
// Inventory Functions
// =====================================================

function addInventoryItem() {
  currentInventoryItemCount++;
  const container = document.getElementById('inventory-items-container');
  const html = `
    <div class="inventory-item card mb-3 p-3">
      <h6 class="mb-3">Product ${currentInventoryItemCount}</h6>
      <div class="row">
        <div class="col-md-6 mb-2">
          <label class="form-label">Barcode</label>
          <input type="text" class="form-control form-control-sm" placeholder="8901234567890" required>
        </div>
        <div class="col-md-6 mb-2">
          <label class="form-label">Product Name</label>
          <input type="text" class="form-control form-control-sm" placeholder="Product Name" required>
        </div>
      </div>

      <div class="mb-2">
        <label class="form-label">Product Description</label>
        <input type="text" class="form-control form-control-sm" placeholder="Product description" required>
      </div>

      <div class="row">
        <div class="col-md-4 mb-2">
          <label class="form-label">Qty in Stock</label>
          <input type="number" class="form-control form-control-sm" placeholder="100" min="0" step="0.01" required>
        </div>
        <div class="col-md-4 mb-2">
          <label class="form-label">Unit Price</label>
          <input